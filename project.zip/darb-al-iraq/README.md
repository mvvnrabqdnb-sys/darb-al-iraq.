# درب العراق | Darb Al-Iraq — ملاحتك بلمسة عراقية

تطبيق ملاحة Android (Kotlin + Jetpack Compose + MapLibre) مع خادم بلاغات مجتمعية.
**اقرأ `docs/REPORT.md` أولاً**: يوضح ما اختُبر فعلاً وما لم يُختبر (لم يُبنَ APK في بيئة الكتابة).

## البنية
```
android/        مشروع Android (app/src/main/java/iq/darb/app: core, data, platform, ui)
android/core-checks/   فحوص المنطق النقي (Kotlin)
server/         خادم البلاغات (Python stdlib + SQLite، بلا اعتماديات) + tests
tools/          gen_styles.py (ستايل الخريطة نهاري/ليلي)، run_core_checks.sh، make_reports_fixture.py
docs/REPORT.md  التقرير الصريح
```

## تشغيل الخادم
```bash
cd server
DARB_DB=darb.sqlite3 DARB_PORT=8080 python3 app.py     # ضعه خلف HTTPS في الإنتاج
python3 -m unittest discover -s tests -v               # 13 اختباراً
```

## بناء التطبيق (على جهازك، يلزم Android Studio / SDK 35)
```bash
cd android
# اختياري: أعد توليد الستايل  python3 ../tools/gen_styles.py
./gradlew assembleDebug -PDARB_REPORTS_URL=https://your-server.example
# الناتج: app/build/outputs/apk/debug/app-debug.apk
```
للمحاكي مع خادم محلي: `-PDARB_REPORTS_URL=http://10.0.2.2:8080`.

عناوين الخدمات (البلاطات، البحث، التوجيه، البلاغات) في `android/gradle.properties` ويمكن تجاوزها بـ `-P`.
الخوادم العامة الافتراضية للتجربة فقط؛ للإنتاج استضِف خدماتك أو استخدم مزوداً تجارياً.

## فحوص المنطق دون Android
```bash
tools/run_core_checks.sh    # يستخدم مترجم Kotlin المضمّن في Gradle، يعمل دون إنترنت
```

بيانات الخريطة © مساهمو OpenStreetMap.
