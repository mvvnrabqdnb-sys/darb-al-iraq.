package iq.darb.app

import android.app.Application
import org.maplibre.android.MapLibre

class DarbApp : Application() {
    override fun onCreate() {
        super.onCreate()
        MapLibre.getInstance(this)
    }
}
