package iq.darb.app

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import iq.darb.app.ui.Accent
import iq.darb.app.ui.DarbTheme
import iq.darb.app.ui.DarbViewModel
import iq.darb.app.ui.FavoritesScreen
import iq.darb.app.ui.MapScreen
import iq.darb.app.ui.Navy
import iq.darb.app.ui.Screen
import iq.darb.app.ui.SearchScreen
import iq.darb.app.ui.SettingsScreen
import iq.darb.app.ui.SplashScreen
import iq.darb.app.ui.tr

class MainActivity : ComponentActivity() {
    private val vm: DarbViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        vm.onPermission(result[Manifest.permission.ACCESS_FINE_LOCATION] == true || result[Manifest.permission.ACCESS_COARSE_LOCATION] == true)
    }

    private fun requestLocation() {
        permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val state by vm.state.collectAsStateWithLifecycle()

            // Keep the screen on only while a trip is active
            LaunchedEffect(state.navigating) {
                if (state.navigating) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
            // Ask for location once, right after the splash
            LaunchedEffect(state.screen) {
                if (state.screen == Screen.MAP && !state.hasLocationPermission) requestLocation()
            }

            DarbTheme(state.settings.theme, state.settings.lang) {
                Column(Modifier.fillMaxSize()) {
                    Box(Modifier.weight(1f)) {
                        when (state.screen) {
                            Screen.SPLASH -> SplashScreen()
                            Screen.MAP -> MapScreen(
                                state, vm,
                                requestPermission = { requestLocation() },
                                openLocationSettings = { startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) },
                            )
                            Screen.SEARCH -> SearchScreen(state, vm)
                            Screen.FAVORITES -> FavoritesScreen(state, vm)
                            Screen.SETTINGS -> SettingsScreen(state, vm)
                        }
                    }
                    if (state.screen != Screen.SPLASH && !state.navigating) BottomBar(state.screen) { vm.go(it) }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.onResume()
    }

    override fun onStop() {
        super.onStop()
        vm.onStop()
    }
}

@Composable
private fun BottomBar(current: Screen, onSelect: (Screen) -> Unit) {
    NavigationBar(modifier = Modifier.navigationBarsPadding(), containerColor = Navy) {
        val colors = NavigationBarItemDefaults.colors(
            selectedIconColor = Navy, selectedTextColor = Accent, indicatorColor = Accent,
            unselectedIconColor = androidx.compose.ui.graphics.Color(0xFFC7D2EA), unselectedTextColor = androidx.compose.ui.graphics.Color(0xFFC7D2EA),
        )
        val items = listOf(
            Triple(Screen.MAP, "🗺️", tr("الخريطة", "Map")),
            Triple(Screen.SEARCH, "🔍", tr("بحث", "Search")),
            Triple(Screen.FAVORITES, "⭐", tr("المفضلة", "Favorites")),
            Triple(Screen.SETTINGS, "⚙️", tr("الإعدادات", "Settings")),
        )
        for ((screen, icon, label) in items) {
            NavigationBarItem(
                selected = current == screen, onClick = { onSelect(screen) },
                icon = { Text(icon, fontSize = 20.sp) }, label = { Text(label, fontSize = 12.sp) }, colors = colors,
            )
        }
    }
}
