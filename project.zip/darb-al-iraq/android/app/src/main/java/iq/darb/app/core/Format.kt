package iq.darb.app.core

import kotlin.math.max
import kotlin.math.roundToInt

object Format {
    /** Short display distance: "850 م" / "3.2 كم" or "850 m" / "3.2 km". */
    fun distance(meters: Double, lang: Lang): String {
        val m = max(0.0, meters)
        return if (m < 1000) {
            val v = if (m >= 100) (m / 10).roundToInt() * 10 else m.roundToInt()
            if (lang == Lang.AR) "$v م" else "$v m"
        } else {
            val km = (m / 100).roundToInt() / 10.0
            val s = if (km == km.toInt().toDouble()) km.toInt().toString() else km.toString()
            if (lang == Lang.AR) "$s كم" else "$s km"
        }
    }

    /** Duration rounded to minutes (min 1). */
    fun duration(seconds: Double, lang: Lang): String {
        val totalMin = max(1, (seconds / 60.0).roundToInt())
        val h = totalMin / 60
        val m = totalMin % 60
        return if (lang == Lang.AR) {
            when {
                h == 0 -> "$m د"
                m == 0 -> "$h س"
                else -> "$h س $m د"
            }
        } else {
            when {
                h == 0 -> "$m min"
                m == 0 -> "$h h"
                else -> "$h h $m min"
            }
        }
    }

    /** Spoken distance used as a prefix: "بعد 300 متر". */
    fun spokenDistance(meters: Double, lang: Lang): String {
        return if (meters < 1000) {
            val v = when {
                meters >= 100 -> (meters / 50).roundToInt() * 50
                else -> max(10, (meters / 10).roundToInt() * 10)
            }
            if (lang == Lang.AR) "بعد $v متر" else "In $v meters"
        } else {
            val km = (meters / 100).roundToInt() / 10.0
            val s = if (km == km.toInt().toDouble()) km.toInt().toString() else km.toString()
            if (lang == Lang.AR) "بعد $s كيلومتر" else "In $s kilometers"
        }
    }
}
