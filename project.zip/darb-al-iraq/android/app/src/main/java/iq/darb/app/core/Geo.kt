package iq.darb.app.core

import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

data class Projection(val point: LatLng, val t: Double, val distanceM: Double)

object Geo {
    private const val R = 6371008.8

    fun distance(a: LatLng, b: LatLng): Double {
        val p1 = Math.toRadians(a.lat)
        val p2 = Math.toRadians(b.lat)
        val dp = p2 - p1
        val dl = Math.toRadians(b.lon - a.lon)
        val h = sin(dp / 2) * sin(dp / 2) + cos(p1) * cos(p2) * sin(dl / 2) * sin(dl / 2)
        return 2 * R * asin(min(1.0, sqrt(h)))
    }

    /** Initial bearing a -> b in degrees [0, 360). */
    fun bearing(a: LatLng, b: LatLng): Double {
        val p1 = Math.toRadians(a.lat)
        val p2 = Math.toRadians(b.lat)
        val dl = Math.toRadians(b.lon - a.lon)
        val y = sin(dl) * cos(p2)
        val x = cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl)
        return (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0
    }

    /** Smallest absolute difference between two bearings, 0..180. */
    fun angleDiff(a: Double, b: Double): Double {
        val d = ((a - b) % 360.0 + 540.0) % 360.0 - 180.0
        return kotlin.math.abs(d)
    }

    /** Projects [p] on segment a-b using a local planar approximation (fine for road-length segments). */
    fun project(p: LatLng, a: LatLng, b: LatLng): Projection {
        val lat0 = Math.toRadians(a.lat)
        val kx = cos(lat0) * R * Math.PI / 180.0
        val ky = R * Math.PI / 180.0
        val bx = (b.lon - a.lon) * kx
        val by = (b.lat - a.lat) * ky
        val px = (p.lon - a.lon) * kx
        val py = (p.lat - a.lat) * ky
        val len2 = bx * bx + by * by
        val t = if (len2 == 0.0) 0.0 else max(0.0, min(1.0, (px * bx + py * by) / len2))
        val cx = bx * t
        val cy = by * t
        val dx = px - cx
        val dy = py - cy
        val point = LatLng(a.lat + (cy / ky), a.lon + (cx / kx))
        return Projection(point, t, sqrt(dx * dx + dy * dy))
    }

    fun polylineLength(points: List<LatLng>): Double {
        var s = 0.0
        for (i in 1 until points.size) s += distance(points[i - 1], points[i])
        return s
    }
}
