package iq.darb.app.core

/** Turn-by-turn text generated on the client from OSRM maneuver data (type + modifier). */
object Instructions {
    private val arOrdinals = listOf(
        "", "الأول", "الثاني", "الثالث", "الرابع", "الخامس",
        "السادس", "السابع", "الثامن", "التاسع", "العاشر",
    )

    fun text(step: RouteStep, lang: Lang, distanceM: Double? = null): String {
        val core = core(step, lang)
        if (distanceM == null) return core
        val prefix = Format.spokenDistance(distanceM, lang)
        return if (lang == Lang.AR) "$prefix، $core" else "$prefix, $core"
    }

    private fun turnPhrase(modifier: String?, lang: Lang): String {
        val ar = lang == Lang.AR
        return when (modifier) {
            "right" -> if (ar) "انعطف يميناً" else "turn right"
            "left" -> if (ar) "انعطف يساراً" else "turn left"
            "slight right" -> if (ar) "انعطف قليلاً إلى اليمين" else "bear right"
            "slight left" -> if (ar) "انعطف قليلاً إلى اليسار" else "bear left"
            "sharp right" -> if (ar) "انعطف بحدّة إلى اليمين" else "turn sharp right"
            "sharp left" -> if (ar) "انعطف بحدّة إلى اليسار" else "turn sharp left"
            "uturn" -> if (ar) "قم بالاستدارة للخلف" else "make a U-turn"
            else -> if (ar) "استمر مستقيماً" else "continue straight"
        }
    }

    private fun sideWord(modifier: String?, lang: Lang): String {
        val right = modifier?.contains("right") == true
        val left = modifier?.contains("left") == true
        return if (lang == Lang.AR) when {
            right -> "على اليمين"
            left -> "على اليسار"
            else -> ""
        } else when {
            right -> "on the right"
            left -> "on the left"
            else -> ""
        }
    }

    fun core(step: RouteStep, lang: Lang): String {
        val ar = lang == Lang.AR
        val name = step.name.trim()
        val to = if (name.isEmpty()) "" else if (ar) " إلى $name" else " onto $name"
        val on = if (name.isEmpty()) "" else if (ar) " على $name" else " on $name"
        return when (step.type) {
            "depart" -> (if (ar) "انطلق" else "Head out") + on
            "arrive" -> {
                val side = sideWord(step.modifier, lang)
                val base = if (ar) "وصلت إلى وجهتك" else "You have arrived at your destination"
                if (side.isEmpty()) base else if (ar) "$base، الوجهة $side" else "$base, destination is $side"
            }
            "turn", "end of road" -> {
                val lead = if (step.type == "end of road") (if (ar) "في نهاية الطريق " else "At the end of the road, ") else ""
                lead + turnPhrase(step.modifier, lang) + (if (step.modifier == "straight" || step.modifier == null) on else to)
            }
            "new name", "continue" ->
                if (step.modifier != null && step.modifier != "straight" && step.type == "continue")
                    turnPhrase(step.modifier, lang) + to
                else (if (ar) "استمر" else "Continue") + on
            "merge" -> (if (ar) "اندمج في الطريق" else "Merge") + on
            "on ramp" -> {
                val side = sideWord(step.modifier, lang)
                (if (ar) "اسلك المنحدر" else "Take the ramp") + (if (side.isEmpty()) "" else " $side") + on
            }
            "off ramp" -> {
                val side = sideWord(step.modifier, lang)
                (if (ar) "اخرج من المخرج" else "Take the exit") + (if (side.isEmpty()) "" else " $side") + on
            }
            "fork" -> {
                val m = step.modifier ?: ""
                if (ar) {
                    val lane = when {
                        m.contains("right") -> "الأيمن"
                        m.contains("left") -> "الأيسر"
                        else -> "الأوسط"
                    }
                    "عند التفرّع خذ المسار $lane" + on
                } else {
                    val lane = when {
                        m.contains("right") -> "right"
                        m.contains("left") -> "left"
                        else -> "middle"
                    }
                    "At the fork keep $lane" + on
                }
            }
            "roundabout", "rotary" -> {
                val e = step.exit
                if (ar) {
                    if (e == null) "ادخل الدوّار"
                    else {
                        val ord = if (e in 1..10) arOrdinals[e] else "رقم $e"
                        "ادخل الدوّار وخذ المخرج $ord" + to
                    }
                } else {
                    if (e == null) "Enter the roundabout" else "At the roundabout take exit $e" + to
                }
            }
            "roundabout turn" -> turnPhrase(step.modifier, lang) + to
            "exit roundabout", "exit rotary" -> (if (ar) "اخرج من الدوّار" else "Exit the roundabout") + to
            else -> (if (ar) "تابع المسير" else "Continue") + on
        }
    }
}
