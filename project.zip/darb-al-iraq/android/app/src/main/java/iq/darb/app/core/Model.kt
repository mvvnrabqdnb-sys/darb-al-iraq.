package iq.darb.app.core

data class LatLng(val lat: Double, val lon: Double)

enum class Lang { AR, EN }

/** One maneuver. [startIndex] is the index in [Route.geometry] where this step begins. */
data class RouteStep(
    val type: String,
    val modifier: String?,
    val name: String,
    val distance: Double,
    val duration: Double,
    val exit: Int?,
    val location: LatLng,
    val startIndex: Int,
)

data class Route(
    val geometry: List<LatLng>,
    val steps: List<RouteStep>,
    val distance: Double,
    val duration: Double,
)

class RoutingException(val code: String, message: String) : Exception(message)
