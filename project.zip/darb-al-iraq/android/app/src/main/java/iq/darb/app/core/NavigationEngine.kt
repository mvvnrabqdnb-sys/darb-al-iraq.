package iq.darb.app.core

import kotlin.math.max
import kotlin.math.min

data class NavState(
    val snapped: LatLng,
    val bearing: Double,
    val progressM: Double,
    val remainingM: Double,
    val remainingSec: Double,
    val stepIndex: Int,
    val nextStep: RouteStep?,
    val distanceToNextM: Double,
    val distanceFromRouteM: Double,
    val offRoute: Boolean,
    val arrived: Boolean,
    /** Spoken/visual announcement to emit now, or null. */
    val announcement: String?,
)

/**
 * Tracks progress of a position along a [Route]: snapping, remaining distance/time,
 * next maneuver, off-route detection (needs consecutive far fixes) and announcement triggering.
 * Pure logic: no Android dependencies.
 */
class NavigationEngine(val route: Route, private val lang: Lang = Lang.AR) {
    private val geo = route.geometry
    private val cum = DoubleArray(geo.size)
    private val stepStart = DoubleArray(route.steps.size)
    private val total: Double
    private var lastSeg = 0
    private var lastProgress = 0.0
    private var offCount = 0
    private val announced = HashSet<String>()

    init {
        require(geo.size >= 2) { "route needs at least 2 points" }
        for (i in 1 until geo.size) cum[i] = cum[i - 1] + Geo.distance(geo[i - 1], geo[i])
        total = cum.last()
        for ((i, s) in route.steps.withIndex()) stepStart[i] = cum[min(s.startIndex, geo.size - 1)]
    }

    private data class Hit(val seg: Int, val proj: Projection)

    private fun search(p: LatLng, from: Int, to: Int): Hit? {
        var best: Hit? = null
        for (i in max(0, from)..min(geo.size - 2, to)) {
            val pr = Geo.project(p, geo[i], geo[i + 1])
            if (best == null || pr.distanceM < best.proj.distanceM) best = Hit(i, pr)
        }
        return best
    }

    fun update(loc: LatLng, accuracyM: Double = 10.0, speedMps: Double = 0.0): NavState {
        var hit = search(loc, lastSeg - 3, lastSeg + 60)
        val tolerance = max(40.0, accuracyM * 2)
        if (hit == null || hit.proj.distanceM > tolerance) {
            val global = search(loc, 0, geo.size - 2)
            if (global != null && (hit == null || global.proj.distanceM < hit.proj.distanceM)) hit = global
        }
        hit!!
        val segLen = cum[hit.seg + 1] - cum[hit.seg]
        var progress = cum[hit.seg] + hit.proj.t * segLen
        if (progress < lastProgress && lastProgress - progress < 40.0) progress = lastProgress // GPS jitter
        lastSeg = hit.seg
        lastProgress = progress

        val offThreshold = max(50.0, accuracyM * 2.5)
        offCount = if (hit.proj.distanceM > offThreshold) offCount + 1 else 0
        val offRoute = offCount >= 3

        val remaining = max(0.0, total - progress)
        var idx = 0
        for (i in route.steps.indices) if (stepStart[i] <= progress + 0.5) idx = i
        val steps = route.steps
        val next = steps.getOrNull(idx + 1)
        val distToNext = if (next != null) max(0.0, stepStart[idx + 1] - progress) else remaining

        var remSec = 0.0
        for (i in idx until steps.size) {
            val s = steps[i]
            remSec += if (i == idx) {
                val frac = if (s.distance <= 0) 1.0 else min(1.0, max(0.0, (progress - stepStart[i]) / s.distance))
                s.duration * (1 - frac)
            } else s.duration
        }
        if (steps.isEmpty()) remSec = route.duration * (remaining / max(total, 1.0))

        val arrived = remaining <= 20.0
        val announcement = if (offRoute) null else announce(idx, next, distToNext, speedMps, arrived)

        val bearing = Geo.bearing(geo[hit.seg], geo[hit.seg + 1])
        return NavState(
            snapped = hit.proj.point, bearing = bearing, progressM = progress, remainingM = remaining,
            remainingSec = remSec, stepIndex = idx, nextStep = next, distanceToNextM = distToNext,
            distanceFromRouteM = hit.proj.distanceM, offRoute = offRoute, arrived = arrived,
            announcement = announcement,
        )
    }

    private fun announce(idx: Int, next: RouteStep?, distToNext: Double, speed: Double, arrived: Boolean): String? {
        if (arrived) {
            val key = "arrived"
            if (announced.add(key)) return route.steps.lastOrNull()?.let { Instructions.text(it, lang) }
            return null
        }
        if (idx == 0 && announced.add("depart")) {
            route.steps.firstOrNull()?.let { if (it.type == "depart") return Instructions.text(it, lang) }
        }
        if (next == null) return null
        // distance thresholds scale with speed (m): far, near, now
        val levels = when {
            speed > 20 -> listOf(1000.0, 400.0, 120.0, 30.0)
            speed > 10 -> listOf(600.0, 300.0, 100.0, 30.0)
            else -> listOf(300.0, 150.0, 60.0, 25.0)
        }
        val stepNo = idx + 1
        // finest level that has been reached and not announced yet
        var chosen = -1
        for (li in levels.indices.reversed()) {
            if (distToNext <= levels[li] && "$stepNo:$li" !in announced) { chosen = li; break }
        }
        if (chosen < 0) return null
        for (li in 0..chosen) announced.add("$stepNo:$li") // never repeat coarser ones afterwards
        val isNow = chosen == levels.size - 1
        return if (isNow) Instructions.text(next, lang) else Instructions.text(next, lang, distToNext)
    }
}
