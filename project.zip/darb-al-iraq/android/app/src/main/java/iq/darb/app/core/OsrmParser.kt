package iq.darb.app.core

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/**
 * Parses an OSRM-compatible /route/v1 response requested with
 * `steps=true&geometries=geojson&overview=false` (step geometries are concatenated into the route geometry).
 * Works with any OSRM-API-compatible backend (OSRM, GraphHopper's OSRM-compat, Valhalla via wrapper, ...).
 */
object OsrmParser {
    fun parse(body: String): List<Route> {
        val root = try {
            Json.parseToJsonElement(body).jsonObject
        } catch (e: Exception) {
            throw RoutingException("BadResponse", "Routing service returned invalid data")
        }
        val code = root["code"]?.jsonPrimitive?.contentOrNull ?: "Unknown"
        if (code != "Ok") {
            throw RoutingException(code, root["message"]?.jsonPrimitive?.contentOrNull ?: code)
        }
        val routes = root["routes"]?.jsonArray ?: throw RoutingException("NoRoute", "No route found")
        if (routes.isEmpty()) throw RoutingException("NoRoute", "No route found")
        return routes.map { parseRoute(it.jsonObject) }
    }

    private fun coord(e: kotlinx.serialization.json.JsonElement): LatLng {
        val a: JsonArray = e.jsonArray
        return LatLng(a[1].jsonPrimitive.doubleOrNull ?: 0.0, a[0].jsonPrimitive.doubleOrNull ?: 0.0)
    }

    private fun parseRoute(r: JsonObject): Route {
        val geometry = ArrayList<LatLng>()
        val steps = ArrayList<RouteStep>()
        for (leg in r["legs"]?.jsonArray ?: JsonArray(emptyList())) {
            for (s in leg.jsonObject["steps"]?.jsonArray ?: JsonArray(emptyList())) {
                val so = s.jsonObject
                val pts = so["geometry"]?.jsonObject?.get("coordinates")?.jsonArray?.map { coord(it) } ?: emptyList()
                val startIndex = if (geometry.isEmpty()) 0 else geometry.size - 1
                for ((i, p) in pts.withIndex()) {
                    if (i == 0 && geometry.isNotEmpty() && geometry.last() == p) continue
                    geometry.add(p)
                }
                val man = so["maneuver"]!!.jsonObject
                steps.add(
                    RouteStep(
                        type = man["type"]?.jsonPrimitive?.contentOrNull ?: "continue",
                        modifier = man["modifier"]?.jsonPrimitive?.contentOrNull,
                        name = so["name"]?.jsonPrimitive?.contentOrNull ?: "",
                        distance = so["distance"]?.jsonPrimitive?.doubleOrNull ?: 0.0,
                        duration = so["duration"]?.jsonPrimitive?.doubleOrNull ?: 0.0,
                        exit = man["exit"]?.jsonPrimitive?.intOrNull,
                        location = coord(man["location"]!!),
                        startIndex = startIndex,
                    )
                )
            }
        }
        if (geometry.size < 2) throw RoutingException("BadResponse", "Route has no geometry")
        return Route(
            geometry = geometry,
            steps = steps,
            distance = r["distance"]?.jsonPrimitive?.doubleOrNull ?: Geo.polylineLength(geometry),
            duration = r["duration"]?.jsonPrimitive?.doubleOrNull ?: steps.sumOf { it.duration },
        )
    }
}
