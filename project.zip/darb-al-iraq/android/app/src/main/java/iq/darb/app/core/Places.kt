package iq.darb.app.core

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlin.math.roundToInt

data class Place(
    val id: String,
    val name: String,
    val subtitle: String,
    val lat: Double,
    val lon: Double,
    val category: String? = null,
) {
    val latLng get() = LatLng(lat, lon)

    fun toJson(): JsonObject = buildJsonObject {
        put("id", id); put("name", name); put("subtitle", subtitle)
        put("lat", lat); put("lon", lon)
        category?.let { put("category", it) }
    }

    companion object {
        fun fromJson(o: JsonObject): Place? = try {
            Place(
                id = o["id"]!!.jsonPrimitive.content,
                name = o["name"]!!.jsonPrimitive.content,
                subtitle = o["subtitle"]?.jsonPrimitive?.contentOrNull ?: "",
                lat = o["lat"]!!.jsonPrimitive.doubleOrNull!!,
                lon = o["lon"]!!.jsonPrimitive.doubleOrNull!!,
                category = o["category"]?.jsonPrimitive?.contentOrNull,
            )
        } catch (e: Exception) {
            null
        }

        fun listToJson(list: List<Place>): String = JsonArray(list.map { it.toJson() }).toString()

        fun listFromJson(s: String?): List<Place> {
            if (s.isNullOrBlank()) return emptyList()
            return try {
                Json.parseToJsonElement(s).jsonArray.mapNotNull { Place.fromJson(it.jsonObject) }
            } catch (e: Exception) {
                emptyList()
            }
        }
    }
}

object ArabicText {
    private val tashkeel = Regex("[\\u064B-\\u065F\\u0670\\u0640]") // harakat, superscript alef, tatweel

    fun isArabic(s: String) = s.any { it in '؀'..'ۿ' }

    /** Normalizes spelling variants so "الموصل" / "الموصـل" / "أربيل" / "اربيل" compare equal. */
    fun normalize(input: String): String {
        var s = input.trim().lowercase()
        s = tashkeel.replace(s, "")
        s = s.replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ٱ', 'ا')
        s = s.replace('ى', 'ي').replace('ئ', 'ي').replace('ؤ', 'و')
        s = s.replace('ة', 'ه')
        s = s.replace('گ', 'ك').replace('ک', 'ك').replace('ی', 'ي').replace('ڤ', 'ف').replace('چ', 'ج').replace('پ', 'ب')
        // Eastern Arabic digits -> Western
        s = s.map { c -> if (c in '٠'..'٩') ('0' + (c - '٠')) else if (c in '۰'..'۹') ('0' + (c - '۰')) else c }
            .joinToString("")
        return s.replace(Regex("\\s+"), " ")
    }
}

object Ranking {
    /**
     * Removes near-duplicates and orders by: name match quality, then proximity to [focus].
     * Pure and deterministic so it can be unit-tested.
     */
    fun rank(results: List<Place>, query: String, focus: LatLng?): List<Place> {
        val q = ArabicText.normalize(query)
        val seen = HashSet<String>()
        val unique = results.filter {
            val key = ArabicText.normalize(it.name) + "|" + (it.lat * 1000).roundToInt() + "|" + (it.lon * 1000).roundToInt()
            seen.add(key)
        }
        fun score(p: Place): Double {
            val n = ArabicText.normalize(p.name)
            val match = when {
                n == q -> 3.0
                n.startsWith(q) -> 2.0
                n.split(" ").any { it.startsWith(q) } -> 1.5
                n.contains(q) -> 1.0
                else -> 0.0
            }
            val prox = if (focus == null) 0.0 else 1.0 / (1.0 + Geo.distance(focus, p.latLng) / 1000.0 / 50.0)
            return match + prox
        }
        return unique.sortedByDescending { score(it) }
    }
}

object PhotonParser {
    fun parse(body: String): List<Place> {
        val root = Json.parseToJsonElement(body).jsonObject
        val feats = root["features"]?.jsonArray ?: return emptyList()
        return feats.mapNotNull { f ->
            try {
                val o = f.jsonObject
                val coords = o["geometry"]!!.jsonObject["coordinates"]!!.jsonArray
                val p = o["properties"]!!.jsonObject
                fun s(k: String) = p[k]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() }
                val name = s("name") ?: s("street") ?: s("city") ?: return@mapNotNull null
                val parts = listOfNotNull(
                    s("street")?.let { st -> (s("housenumber")?.let { "$st $it" } ?: st).takeIf { it != name } },
                    s("district"), s("city"), s("county"), s("state"), s("country"),
                ).filter { it != name }.distinct()
                Place(
                    id = "${s("osm_type") ?: "?"}${s("osm_id") ?: coords.toString()}",
                    name = name,
                    subtitle = parts.joinToString("، "),
                    lat = coords[1].jsonPrimitive.doubleOrNull!!,
                    lon = coords[0].jsonPrimitive.doubleOrNull!!,
                    category = s("osm_value"),
                )
            } catch (e: Exception) {
                null
            }
        }
    }
}

object OverpassParser {
    fun parse(body: String, category: String, preferArabic: Boolean): List<Place> {
        val root = Json.parseToJsonElement(body).jsonObject
        val els = root["elements"]?.jsonArray ?: return emptyList()
        return els.mapNotNull { e ->
            try {
                val o = e.jsonObject
                val tags = o["tags"]?.jsonObject ?: JsonObject(emptyMap())
                fun t(k: String) = tags[k]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() }
                val name = (if (preferArabic) t("name:ar") else t("name:en")) ?: t("name") ?: t("name:ar") ?: t("name:en") ?: t("brand")
                    ?: return@mapNotNull null
                val lat = o["lat"]?.jsonPrimitive?.doubleOrNull ?: o["center"]?.jsonObject?.get("lat")?.jsonPrimitive?.doubleOrNull
                ?: return@mapNotNull null
                val lon = o["lon"]?.jsonPrimitive?.doubleOrNull ?: o["center"]?.jsonObject?.get("lon")?.jsonPrimitive?.doubleOrNull
                ?: return@mapNotNull null
                val addr = listOfNotNull(t("addr:street"), t("addr:city")).joinToString("، ")
                Place("${o["type"]?.jsonPrimitive?.contentOrNull}${o["id"]?.jsonPrimitive?.contentOrNull}", name, addr, lat, lon, category)
            } catch (ex: Exception) {
                null
            }
        }
    }
}
