package iq.darb.app.core

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull

/** [id] matches the type string used by the reports server. [color] is ARGB. */
enum class ReportType(val id: String, val ar: String, val en: String, val emoji: String, val color: Long) {
    TRAFFIC("traffic", "زحام مروري", "Traffic jam", "🚗", 0xFFE53935),
    ACCIDENT("accident", "حادث مروري", "Accident", "💥", 0xFFD81B60),
    POTHOLE("pothole", "حفرة في الطريق", "Pothole", "🕳️", 0xFF8D6E63),
    SPEEDBUMP("speedbump", "مطب", "Speed bump", "〰️", 0xFFFB8C00),
    CLOSURE("closure", "طريق مغلق", "Road closed", "⛔", 0xFFB71C1C),
    CONSTRUCTION("construction", "أعمال صيانة", "Road works", "🚧", 0xFFF9A825),
    CHECKPOINT("checkpoint", "سيطرة (غير مؤكدة)", "Checkpoint (unverified)", "🛂", 0xFF546E7A),
    HAZARD("hazard", "خطر على الطريق", "Road hazard", "⚠️", 0xFFFF6F00),
    DUST("dust", "غبار وضعف رؤية", "Dust / low visibility", "🌫️", 0xFF9E9E9E),
    FLOOD("flood", "تجمّع مياه", "Flooding", "🌊", 0xFF1E88E5),
    OBSTACLE("obstacle", "عائق في الطريق", "Obstacle", "🪨", 0xFF6D4C41),
    FUEL("fuel", "محطة وقود", "Fuel station issue", "⛽", 0xFF43A047);

    fun label(lang: Lang) = if (lang == Lang.AR) ar else en

    companion object {
        fun fromId(id: String) = entries.firstOrNull { it.id == id }
    }
}

data class Report(
    val id: String,
    val type: ReportType,
    val lat: Double,
    val lon: Double,
    val note: String?,
    val createdAt: Long,
    val expiresAt: Long,
    val confirmations: Int,
    val goneVotes: Int,
    val verified: Boolean,
    val unverifiedSensitive: Boolean,
    val confidence: Double,
    val status: String = "active",
) {
    val latLng get() = LatLng(lat, lon)
}

object ReportsParser {
    fun parseOne(o: kotlinx.serialization.json.JsonObject): Report? {
        return try {
            fun p(k: String) = o[k]?.jsonPrimitive
            Report(
                id = p("id")!!.content,
                type = ReportType.fromId(p("type")!!.content) ?: return null,
                lat = p("lat")!!.doubleOrNull!!,
                lon = p("lon")!!.doubleOrNull!!,
                note = p("note")?.contentOrNull,
                createdAt = p("created_at")?.longOrNull ?: 0L,
                expiresAt = p("expires_at")?.longOrNull ?: 0L,
                confirmations = p("confirmations")?.intOrNull ?: 0,
                goneVotes = p("gone_votes")?.intOrNull ?: 0,
                verified = p("verified")?.booleanOrNull ?: false,
                unverifiedSensitive = p("unverified_sensitive")?.booleanOrNull ?: false,
                confidence = p("confidence")?.doubleOrNull ?: 0.0,
                status = p("status")?.contentOrNull ?: "active",
            )
        } catch (e: Exception) {
            null
        }
    }

    fun parseList(body: String): List<Report> {
        val arr = Json.parseToJsonElement(body).jsonObject["reports"]?.jsonArray ?: return emptyList()
        return arr.mapNotNull { parseOne(it.jsonObject) }
    }

    fun parseSingle(body: String): Report? = parseOne(Json.parseToJsonElement(body).jsonObject)

    fun errorMessage(body: String): String? = try {
        Json.parseToJsonElement(body).jsonObject["error"]?.jsonPrimitive?.contentOrNull
    } catch (e: Exception) {
        null
    }
}
