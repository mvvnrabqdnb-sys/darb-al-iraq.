package iq.darb.app.core

/** Fills the placeholders of the generated style JSON (see tools/gen_styles.py). */
object StyleTemplate {
    fun nameExpression(lang: Lang): String = if (lang == Lang.AR)
        """["coalesce",["get","name:ar"],["get","name_ar"],["get","name"],["get","name_en"]]"""
    else
        """["coalesce",["get","name_en"],["get","name:en"],["get","name:latin"],["get","name"]]"""

    fun fill(template: String, tileJsonUrl: String, glyphsUrl: String, lang: Lang): String =
        template
            .replace("\"__NAME_EXPR__\"", nameExpression(lang))
            .replace("__TILEJSON_URL__", tileJsonUrl)
            .replace("__GLYPHS_URL__", glyphsUrl)
}
