package iq.darb.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runInterruptible
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit

enum class NetKind { OFFLINE, TIMEOUT, SERVER, RATE_LIMITED, UNAUTHORIZED, CLIENT }

class NetworkException(val kind: NetKind, val status: Int = 0, val body: String = "") : Exception("$kind $status")

object Http {
    private const val UA = "DarbAlIraq/0.1 (Android; contact: set-your-contact-here)"

    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .callTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun get(url: String, headers: Map<String, String> = emptyMap()): String =
        execute(Request.Builder().url(url).header("User-Agent", UA).apply { headers.forEach { (k, v) -> header(k, v) } }.build())

    suspend fun post(url: String, json: String, headers: Map<String, String> = emptyMap()): String =
        execute(
            Request.Builder().url(url).header("User-Agent", UA)
                .apply { headers.forEach { (k, v) -> header(k, v) } }
                .post(json.toRequestBody("application/json; charset=utf-8".toMediaType())).build()
        )

    suspend fun postForm(url: String, form: String): String =
        execute(
            Request.Builder().url(url).header("User-Agent", UA)
                .post(form.toRequestBody("application/x-www-form-urlencoded".toMediaType())).build()
        )

    private suspend fun execute(req: Request): String = runInterruptible(Dispatchers.IO) {
        try {
            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (resp.isSuccessful) return@use body
                throw NetworkException(
                    when {
                        resp.code == 429 -> NetKind.RATE_LIMITED
                        resp.code == 401 -> NetKind.UNAUTHORIZED
                        resp.code >= 500 -> NetKind.SERVER
                        else -> NetKind.CLIENT
                    }, resp.code, body
                )
            }
        } catch (e: NetworkException) {
            throw e
        } catch (e: SocketTimeoutException) {
            throw NetworkException(NetKind.TIMEOUT)
        } catch (e: IOException) {
            throw NetworkException(NetKind.OFFLINE)
        }
    }
}
