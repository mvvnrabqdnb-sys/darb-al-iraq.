package iq.darb.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import iq.darb.app.core.Lang
import iq.darb.app.core.Place

enum class ThemeMode { SYSTEM, DAY, NIGHT }

data class Settings(
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val lang: Lang = Lang.AR,
    val muted: Boolean = false,
    val buildings3d: Boolean = true,
)

class Prefs(context: Context) {
    private val sp: SharedPreferences = context.getSharedPreferences("darb", Context.MODE_PRIVATE)

    /** Reports-server credential lives in encrypted storage (falls back to plain prefs only if Keystore is unusable). */
    private val secure: SharedPreferences = try {
        val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            context, "darb_secure", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    } catch (e: Exception) {
        context.getSharedPreferences("darb_secure_fallback", Context.MODE_PRIVATE)
    }

    fun loadSettings() = Settings(
        theme = runCatching { ThemeMode.valueOf(sp.getString("theme", "SYSTEM")!!) }.getOrDefault(ThemeMode.SYSTEM),
        lang = if (sp.getString("lang", "AR") == "EN") Lang.EN else Lang.AR,
        muted = sp.getBoolean("muted", false),
        buildings3d = sp.getBoolean("b3d", true),
    )

    fun saveSettings(s: Settings) {
        sp.edit().putString("theme", s.theme.name).putString("lang", s.lang.name)
            .putBoolean("muted", s.muted).putBoolean("b3d", s.buildings3d).apply()
    }

    fun favorites(): List<Place> = Place.listFromJson(sp.getString("favorites", null))
    fun saveFavorites(l: List<Place>) = sp.edit().putString("favorites", Place.listToJson(l)).apply()

    fun recents(): List<Place> = Place.listFromJson(sp.getString("recents", null))
    fun saveRecents(l: List<Place>) = sp.edit().putString("recents", Place.listToJson(l.take(15))).apply()

    fun reportsToken(): String? = secure.getString("reports_token", null)
    fun saveReportsToken(t: String) = secure.edit().putString("reports_token", t).apply()
}
