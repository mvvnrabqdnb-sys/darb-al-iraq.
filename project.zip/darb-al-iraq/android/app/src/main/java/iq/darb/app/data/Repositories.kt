package iq.darb.app.data

import iq.darb.app.BuildConfig
import iq.darb.app.core.ArabicText
import iq.darb.app.core.LatLng
import iq.darb.app.core.OsrmParser
import iq.darb.app.core.OverpassParser
import iq.darb.app.core.PhotonParser
import iq.darb.app.core.Place
import iq.darb.app.core.Ranking
import iq.darb.app.core.Report
import iq.darb.app.core.ReportType
import iq.darb.app.core.ReportsParser
import iq.darb.app.core.Route
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import java.net.URLEncoder

private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

/** Provider interfaces keep the app independent of any single vendor. */
interface SearchProvider {
    suspend fun search(query: String, focus: LatLng?, preferArabic: Boolean): List<Place>
    suspend fun reverse(point: LatLng): Place?
    suspend fun nearby(category: String, center: LatLng, preferArabic: Boolean): List<Place>
}

interface RoutingProvider {
    suspend fun routes(from: LatLng, to: LatLng, alternatives: Boolean): List<Route>
}

/** Plug-in point for live traffic. No free provider with Iraq coverage is bundled. */
interface TrafficProvider {
    val available: Boolean
}

object NoTraffic : TrafficProvider {
    override val available = false
}

/** Photon geocoder (autocomplete + reverse) with Overpass for category searches near a point. */
class PhotonSearch(
    private val baseUrl: String = BuildConfig.SEARCH_URL,
    private val overpassUrl: String = "https://overpass-api.de/api/interpreter",
) : SearchProvider {

    override suspend fun search(query: String, focus: LatLng?, preferArabic: Boolean): List<Place> {
        suspend fun call(q: String): List<Place> {
            val bias = focus?.let { "&lat=${it.lat}&lon=${it.lon}" } ?: ""
            val body = Http.get("$baseUrl/api/?q=${enc(q)}&limit=12$bias")
            return PhotonParser.parse(body)
        }
        var results = call(query)
        if (results.isEmpty() && ArabicText.isArabic(query)) {
            val n = ArabicText.normalize(query)
            if (n != query.trim().lowercase()) results = call(n)
        }
        return Ranking.rank(results, query, focus)
    }

    override suspend fun reverse(point: LatLng): Place? {
        val body = Http.get("$baseUrl/reverse?lat=${point.lat}&lon=${point.lon}")
        return PhotonParser.parse(body).firstOrNull()?.copy(lat = point.lat, lon = point.lon)
    }

    override suspend fun nearby(category: String, center: LatLng, preferArabic: Boolean): List<Place> {
        val (key, value) = when (category) {
            "fuel" -> "amenity" to "fuel"
            "hospital" -> "amenity" to "hospital"
            "pharmacy" -> "amenity" to "pharmacy"
            "restaurant" -> "amenity" to "restaurant"
            "supermarket" -> "shop" to "supermarket"
            else -> "amenity" to category
        }
        val q = "[out:json][timeout:15];nwr[$key=$value](around:4000,${center.lat},${center.lon});out center 40;"
        val body = Http.postForm(overpassUrl, "data=${enc(q)}")
        val places = OverpassParser.parse(body, category, preferArabic)
        return places.sortedBy { iq.darb.app.core.Geo.distance(center, it.latLng) }
    }
}

/** Any OSRM-API-compatible server. */
class OsrmRouting(private val baseUrl: String = BuildConfig.ROUTING_URL) : RoutingProvider {
    override suspend fun routes(from: LatLng, to: LatLng, alternatives: Boolean): List<Route> {
        val url = "$baseUrl/route/v1/driving/${from.lon},${from.lat};${to.lon},${to.lat}" +
            "?steps=true&geometries=geojson&overview=false&alternatives=$alternatives"
        return OsrmParser.parse(
            try {
                Http.get(url)
            } catch (e: NetworkException) {
                // OSRM answers 400 with a JSON body for NoRoute/NoSegment; let the parser turn it into a RoutingException
                if (e.kind == NetKind.CLIENT && e.body.startsWith("{")) e.body else throw e
            }
        )
    }
}

class ReportsRepo(private val prefs: Prefs, private val baseUrl: String = BuildConfig.REPORTS_URL) {
    val enabled get() = baseUrl.isNotBlank()

    /** Registers an anonymous device with the server and stores the returned credential securely. */
    private suspend fun register(): String {
        val body = Http.post("$baseUrl/v1/devices", "{}")
        val token = try {
            kotlinx.serialization.json.Json.parseToJsonElement(body)
                .jsonObject["token"]!!.jsonPrimitive.content
        } catch (e: Exception) {
            throw NetworkException(NetKind.SERVER)
        }
        prefs.saveReportsToken(token)
        return token
    }

    private suspend fun <T> withAuth(block: suspend (Map<String, String>) -> T): T {
        val token = prefs.reportsToken()?.takeIf { it.isNotBlank() } ?: register()
        return try {
            block(mapOf("Authorization" to "Bearer $token"))
        } catch (e: NetworkException) {
            if (e.kind != NetKind.UNAUTHORIZED) throw e
            // credential unknown to the server (e.g. database reset): register once more and retry once
            block(mapOf("Authorization" to "Bearer ${register()}"))
        }
    }

    suspend fun list(minLon: Double, minLat: Double, maxLon: Double, maxLat: Double): List<Report> =
        ReportsParser.parseList(Http.get("$baseUrl/v1/reports?bbox=$minLon,$minLat,$maxLon,$maxLat"))

    suspend fun create(type: ReportType, at: LatLng, note: String? = null): Report? = withAuth { h ->
        val json = buildJsonObject {
            put("type", type.id); put("lat", at.lat); put("lon", at.lon)
            if (note != null) put("note", note)
        }.toString()
        ReportsParser.parseSingle(Http.post("$baseUrl/v1/reports", json, h))
    }

    suspend fun vote(id: String, confirm: Boolean): Report? = withAuth { h ->
        val json = buildJsonObject { put("vote", if (confirm) "confirm" else "gone") }.toString()
        ReportsParser.parseSingle(Http.post("$baseUrl/v1/reports/$id/vote", json, h))
    }
}
