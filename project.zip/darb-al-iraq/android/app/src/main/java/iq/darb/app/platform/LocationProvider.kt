package iq.darb.app.platform

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import androidx.core.content.ContextCompat

/**
 * Plain framework LocationManager (no Google Play Services dependency, so it also works on devices without GMS).
 * Battery: relaxed intervals while browsing, 1 Hz GPS while navigating.
 */
class LocationProvider(
    private val context: Context,
    private val onLocation: (Location) -> Unit,
    private val onProviderState: (gpsEnabled: Boolean) -> Unit,
) {
    private val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private var running = false
    private var navigating = false

    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) = onLocation(location)
        override fun onProviderEnabled(provider: String) = onProviderState(isGpsEnabled())
        override fun onProviderDisabled(provider: String) = onProviderState(isGpsEnabled())

        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
        }
    }

    fun hasPermission() = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
        PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) ==
        PackageManager.PERMISSION_GRANTED

    fun isGpsEnabled() = runCatching { lm.isProviderEnabled(LocationManager.GPS_PROVIDER) }.getOrDefault(false)

    @SuppressLint("MissingPermission")
    fun start(navigating: Boolean) {
        if (!hasPermission()) return
        if (running && this.navigating == navigating) return
        stop()
        this.navigating = navigating
        running = true
        val gpsInterval = if (navigating) 1000L else 4000L
        val gpsDistance = if (navigating) 0f else 10f
        runCatching {
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER))
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, gpsInterval, gpsDistance, listener, Looper.getMainLooper())
        }
        runCatching {
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 6000L, 20f, listener, Looper.getMainLooper())
        }
        // immediate best-known fix so the map can center before the first live update
        runCatching {
            listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
                .mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time }?.let(onLocation)
        }
        onProviderState(isGpsEnabled())
    }

    fun stop() {
        runCatching { lm.removeUpdates(listener) }
        running = false
    }
}
