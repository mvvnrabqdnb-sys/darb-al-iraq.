package iq.darb.app.platform

import android.content.Context
import android.speech.tts.TextToSpeech
import iq.darb.app.core.Lang
import java.util.Locale

/** Text-to-speech wrapper. Arabic voice availability depends on the device's TTS engine/voice data. */
class Speaker(context: Context, private val onReady: (arabicAvailable: Boolean) -> Unit) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    private var ready = false

    override fun onInit(status: Int) {
        val engine = tts
        if (status != TextToSpeech.SUCCESS || engine == null) {
            onReady(false)
            return
        }
        ready = true
        val r = engine.isLanguageAvailable(Locale("ar"))
        onReady(r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED)
    }

    fun speak(text: String, lang: Lang) {
        val engine = tts ?: return
        if (!ready || text.isBlank()) return
        engine.language = if (lang == Lang.AR) Locale("ar") else Locale.ENGLISH
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "darb-nav")
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
