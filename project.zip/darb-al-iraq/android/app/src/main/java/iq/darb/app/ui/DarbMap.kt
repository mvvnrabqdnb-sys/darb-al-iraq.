package iq.darb.app.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.location.Location
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import iq.darb.app.BuildConfig
import iq.darb.app.core.Lang
import iq.darb.app.core.Place
import iq.darb.app.core.Report
import iq.darb.app.core.ReportType
import iq.darb.app.core.Route
import iq.darb.app.core.StyleTemplate
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.location.LocationComponentActivationOptions
import org.maplibre.android.location.modes.CameraMode
import org.maplibre.android.location.modes.RenderMode
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.expressions.Expression
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.layers.SymbolLayer
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.LineString
import org.maplibre.geojson.Point

private const val SRC_ROUTE = "darb-route-src"
private const val SRC_ALT = "darb-alt-src"
private const val SRC_DEST = "darb-dest-src"
private const val SRC_REPORTS = "darb-reports-src"
private const val LAYER_REPORTS = "darb-reports-layer"

/** Everything the map needs to render; the map never owns app state. */
data class MapInput(
    val night: Boolean,
    val lang: Lang,
    val buildings3d: Boolean,
    val location: Location?,
    val permission: Boolean,
    val following: Boolean,
    val navigating: Boolean,
    val navBearing: Float?,
    val routes: List<Route>,
    val routeIndex: Int,
    val destination: Place?,
    val reports: List<Report>,
    val northResetNonce: Int,
)

class MapCallbacks(
    val onLongPress: (iq.darb.app.core.LatLng) -> Unit,
    val onReportTap: (String) -> Unit,
    val onUserGesture: () -> Unit,
    val onBounds: (Double, Double, Double, Double) -> Unit,
    val onCenter: (iq.darb.app.core.LatLng) -> Unit,
)

private class MapHolder {
    // Compose state so the LaunchedEffects below re-run once the async map/style become ready.
    var map by mutableStateOf<MapLibreMap?>(null)
    var style by mutableStateOf<Style?>(null)
    var styleKey: String? = null
    var programmaticMove = false
}

private fun reportBitmap(type: ReportType, dim: Boolean): Bitmap {
    val size = 96
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.color = 0xFFFFFFFF.toInt()
    c.drawCircle(size / 2f, size / 2f, size / 2f - 2, p)
    p.color = (if (dim) 0xFF90A4AE else type.color).toInt()
    c.drawCircle(size / 2f, size / 2f, size / 2f - 8, p)
    p.color = 0xFFFFFFFF.toInt()
    p.textSize = 44f
    p.textAlign = Paint.Align.CENTER
    p.typeface = Typeface.DEFAULT
    c.drawText(type.emoji, size / 2f, size / 2f + 15f, p)
    return bmp
}

private fun lineFeature(route: Route): Feature =
    Feature.fromGeometry(LineString.fromLngLats(route.geometry.map { Point.fromLngLat(it.lon, it.lat) }))

@SuppressLint("MissingPermission")
@Composable
fun DarbMap(modifier: Modifier, input: MapInput, callbacks: MapCallbacks) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val mapView = remember { MapView(context) }
    val holder = remember { MapHolder() }

    // --- MapView lifecycle ---
    DisposableEffect(lifecycle, mapView) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_CREATE -> mapView.onCreate(null)
                Lifecycle.Event.ON_START -> mapView.onStart()
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                Lifecycle.Event.ON_STOP -> mapView.onStop()
                Lifecycle.Event.ON_DESTROY -> mapView.onDestroy()
                else -> {}
            }
        }
        lifecycle.addObserver(obs)
        // The Compose host is already past ON_CREATE when this runs
        if (lifecycle.currentState.isAtLeast(Lifecycle.State.CREATED)) mapView.onCreate(null)
        if (lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) mapView.onStart()
        if (lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) mapView.onResume()
        onDispose {
            lifecycle.removeObserver(obs)
            mapView.onPause(); mapView.onStop(); mapView.onDestroy()
        }
    }

    // --- one-time map setup ---
    DisposableEffect(mapView) {
        mapView.getMapAsync { map ->
            holder.map = map
            map.uiSettings.isCompassEnabled = false
            map.uiSettings.isAttributionEnabled = true   // OSM / tile provider attribution is a licence requirement
            map.uiSettings.isLogoEnabled = false
            map.setMinZoomPreference(3.0)
            // Start over Iraq until we have a location fix
            map.cameraPosition = CameraPosition.Builder().target(LatLng(33.2, 44.0)).zoom(5.6).build()
            map.addOnMapLongClickListener { p ->
                callbacks.onLongPress(iq.darb.app.core.LatLng(p.latitude, p.longitude)); true
            }
            map.addOnMapClickListener { p ->
                val style = holder.style
                if (style != null && style.getLayer(LAYER_REPORTS) != null) {
                    val screen = map.projection.toScreenLocation(p)
                    val hit = map.queryRenderedFeatures(screen, LAYER_REPORTS).firstOrNull()
                    val id = hit?.getStringProperty("id")
                    if (id != null) { callbacks.onReportTap(id); return@addOnMapClickListener true }
                }
                false
            }
            map.addOnCameraMoveStartedListener { reason ->
                if (reason == MapLibreMap.OnCameraMoveStartedListener.REASON_API_GESTURE && !holder.programmaticMove)
                    callbacks.onUserGesture()
            }
            map.addOnCameraIdleListener {
                val b = map.projection.visibleRegion.latLngBounds
                callbacks.onBounds(b.longitudeWest, b.latitudeSouth, b.longitudeEast, b.latitudeNorth)
                val t = map.cameraPosition.target
                if (t != null) callbacks.onCenter(iq.darb.app.core.LatLng(t.latitude, t.longitude))
            }
        }
        onDispose { }
    }

    // --- style (day/night, language) ---
    LaunchedEffect(input.night, input.lang, holder.map) {
        val map = holder.map ?: return@LaunchedEffect
        val key = "${input.night}-${input.lang}"
        if (holder.styleKey == key) return@LaunchedEffect
        holder.styleKey = key
        val asset = if (input.night) "style_night.json" else "style_day.json"
        val template = context.assets.open(asset).bufferedReader(Charsets.UTF_8).use { it.readText() }
        val json = StyleTemplate.fill(template, BuildConfig.TILEJSON_URL, BuildConfig.GLYPHS_URL, input.lang)
        map.setStyle(Style.Builder().fromJson(json)) { style ->
            holder.style = style
            installOverlays(style)
            holder.styleKey = key
            if (input.permission) {
                runCatching {
                    val lc = map.locationComponent
                    lc.activateLocationComponent(
                        LocationComponentActivationOptions.builder(context, style).useDefaultLocationEngine(false).build()
                    )
                    lc.isLocationComponentEnabled = true
                    lc.cameraMode = CameraMode.NONE
                    lc.renderMode = RenderMode.GPS
                }
            }
        }
    }

    // --- 3D buildings toggle ---
    LaunchedEffect(input.buildings3d, holder.style) {
        holder.style?.getLayer("building_3d")?.setProperties(
            PropertyFactory.visibility(if (input.buildings3d) Property.VISIBLE else Property.NONE)
        )
    }

    // --- user position (arrow) ---
    LaunchedEffect(input.location, input.permission, holder.style) {
        val map = holder.map ?: return@LaunchedEffect
        val loc = input.location ?: return@LaunchedEffect
        runCatching {
            val lc = map.locationComponent
            if (lc.isLocationComponentActivated) lc.forceLocationUpdate(loc)
        }
        if (input.following) {
            val bearing = if (input.navigating) (input.navBearing ?: loc.bearing).toDouble() else map.cameraPosition.bearing
            val cam = CameraPosition.Builder()
                .target(LatLng(loc.latitude, loc.longitude))
                .zoom(if (input.navigating) 17.0 else maxOf(map.cameraPosition.zoom, 14.5))
                .bearing(bearing)
                .tilt(if (input.navigating) 55.0 else 0.0)
                .build()
            holder.programmaticMove = true
            map.animateCamera(CameraUpdateFactory.newCameraPosition(cam), 900, object : MapLibreMap.CancelableCallback {
                override fun onCancel() { holder.programmaticMove = false }
                override fun onFinish() { holder.programmaticMove = false }
            })
        }
    }

    // --- routes ---
    LaunchedEffect(input.routes, input.routeIndex, holder.style) {
        val style = holder.style ?: return@LaunchedEffect
        val main = input.routes.getOrNull(input.routeIndex)
        style.getSourceAs<GeoJsonSource>(SRC_ROUTE)?.setGeoJson(
            if (main != null) FeatureCollection.fromFeature(lineFeature(main)) else FeatureCollection.fromFeatures(arrayOf<Feature>())
        )
        val alts = input.routes.filterIndexed { i, _ -> i != input.routeIndex }.map { lineFeature(it) }
        style.getSourceAs<GeoJsonSource>(SRC_ALT)?.setGeoJson(FeatureCollection.fromFeatures(alts))
        // Fit the whole route when previewing (not while driving)
        if (main != null && !input.navigating) {
            val map = holder.map ?: return@LaunchedEffect
            val b = org.maplibre.android.geometry.LatLngBounds.Builder()
            main.geometry.forEach { b.include(LatLng(it.lat, it.lon)) }
            holder.programmaticMove = true
            map.animateCamera(CameraUpdateFactory.newLatLngBounds(b.build(), 120, 260, 120, 420), 900,
                object : MapLibreMap.CancelableCallback {
                    override fun onCancel() { holder.programmaticMove = false }
                    override fun onFinish() { holder.programmaticMove = false }
                })
        }
    }

    // --- destination pin ---
    LaunchedEffect(input.destination, holder.style) {
        val style = holder.style ?: return@LaunchedEffect
        val d = input.destination
        style.getSourceAs<GeoJsonSource>(SRC_DEST)?.setGeoJson(
            if (d != null) FeatureCollection.fromFeature(Feature.fromGeometry(Point.fromLngLat(d.lon, d.lat)))
            else FeatureCollection.fromFeatures(arrayOf<Feature>())
        )
        if (d != null && !input.navigating && input.routes.isEmpty()) {
            holder.programmaticMove = true
            holder.map?.animateCamera(
                CameraUpdateFactory.newCameraPosition(CameraPosition.Builder().target(LatLng(d.lat, d.lon)).zoom(15.5).bearing(0.0).tilt(0.0).build()),
                900, object : MapLibreMap.CancelableCallback {
                    override fun onCancel() { holder.programmaticMove = false }
                    override fun onFinish() { holder.programmaticMove = false }
                })
        }
    }

    // --- community reports ---
    LaunchedEffect(input.reports, holder.style) {
        val style = holder.style ?: return@LaunchedEffect
        val feats = input.reports.map { r ->
            val f = Feature.fromGeometry(Point.fromLngLat(r.lon, r.lat))
            f.addStringProperty("id", r.id)
            // sensitive categories stay visually "dim" until independently confirmed
            f.addStringProperty("icon", "rep-${r.type.id}-${if (r.unverifiedSensitive) "dim" else "ok"}")
            f
        }
        style.getSourceAs<GeoJsonSource>(SRC_REPORTS)?.setGeoJson(FeatureCollection.fromFeatures(feats))
    }

    // --- recenter north (compass button) ---
    LaunchedEffect(input.northResetNonce) {
        if (input.northResetNonce == 0) return@LaunchedEffect
        val map = holder.map ?: return@LaunchedEffect
        val c = map.cameraPosition
        map.animateCamera(CameraUpdateFactory.newCameraPosition(CameraPosition.Builder(c).bearing(0.0).tilt(0.0).build()), 500)
    }

    AndroidView(factory = { mapView }, modifier = modifier)
}

private fun installOverlays(style: Style) {
    val empty = { FeatureCollection.fromFeatures(arrayOf<Feature>()) }
    style.addSource(GeoJsonSource(SRC_ALT, empty()))
    style.addSource(GeoJsonSource(SRC_ROUTE, empty()))
    style.addSource(GeoJsonSource(SRC_DEST, empty()))
    style.addSource(GeoJsonSource(SRC_REPORTS, empty()))

    style.addLayer(
        LineLayer("darb-alt-layer", SRC_ALT).withProperties(
            PropertyFactory.lineColor("#8D99AE"), PropertyFactory.lineWidth(6f),
            PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
        )
    )
    style.addLayer(
        LineLayer("darb-route-casing", SRC_ROUTE).withProperties(
            PropertyFactory.lineColor("#0B3D91"), PropertyFactory.lineWidth(11f),
            PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
        )
    )
    style.addLayer(
        LineLayer("darb-route-layer", SRC_ROUTE).withProperties(
            PropertyFactory.lineColor("#3D8BFF"), PropertyFactory.lineWidth(7f),
            PropertyFactory.lineCap(Property.LINE_CAP_ROUND), PropertyFactory.lineJoin(Property.LINE_JOIN_ROUND),
        )
    )
    style.addLayer(
        CircleLayer("darb-dest-layer", SRC_DEST).withProperties(
            PropertyFactory.circleRadius(9f), PropertyFactory.circleColor("#E53935"),
            PropertyFactory.circleStrokeColor("#FFFFFF"), PropertyFactory.circleStrokeWidth(3f),
        )
    )
    for (t in ReportType.entries) {
        style.addImage("rep-${t.id}-ok", reportBitmap(t, false))
        style.addImage("rep-${t.id}-dim", reportBitmap(t, true))
    }
    style.addLayer(
        SymbolLayer(LAYER_REPORTS, SRC_REPORTS).withProperties(
            PropertyFactory.iconImage(Expression.get("icon")),
            PropertyFactory.iconAllowOverlap(true),
            PropertyFactory.iconIgnorePlacement(true),
            PropertyFactory.iconSize(0.6f),
        )
    )
}
