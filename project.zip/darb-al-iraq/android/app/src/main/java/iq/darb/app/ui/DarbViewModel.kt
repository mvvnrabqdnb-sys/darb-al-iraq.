package iq.darb.app.ui

import android.app.Application
import android.location.Location
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import iq.darb.app.core.Lang
import iq.darb.app.core.LatLng
import iq.darb.app.core.NavState
import iq.darb.app.core.NavigationEngine
import iq.darb.app.core.Place
import iq.darb.app.core.Report
import iq.darb.app.core.ReportType
import iq.darb.app.core.Route
import iq.darb.app.core.RoutingException
import iq.darb.app.data.NetKind
import iq.darb.app.data.NetworkException
import iq.darb.app.data.NoTraffic
import iq.darb.app.data.OsrmRouting
import iq.darb.app.data.PhotonSearch
import iq.darb.app.data.Prefs
import iq.darb.app.data.ReportsRepo
import iq.darb.app.data.Settings
import iq.darb.app.data.ThemeMode
import iq.darb.app.platform.LocationProvider
import iq.darb.app.platform.Speaker
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class Screen { SPLASH, MAP, SEARCH, FAVORITES, SETTINGS }

data class UiState(
    val screen: Screen = Screen.SPLASH,
    val settings: Settings = Settings(),
    val hasLocationPermission: Boolean = false,
    val gpsEnabled: Boolean = true,
    val myLocation: Location? = null,
    val gpsLost: Boolean = false,
    val following: Boolean = true,
    val query: String = "",
    val searching: Boolean = false,
    val results: List<Place> = emptyList(),
    val searchMessage: String? = null,
    val selected: Place? = null,
    val favorites: List<Place> = emptyList(),
    val recents: List<Place> = emptyList(),
    val routes: List<Route> = emptyList(),
    val routeIndex: Int = 0,
    val routing: Boolean = false,
    val routeMessage: String? = null,
    val navigating: Boolean = false,
    val nav: NavState? = null,
    val rerouting: Boolean = false,
    val reports: List<Report> = emptyList(),
    val selectedReport: Report? = null,
    val reportSheet: Boolean = false,
    val toast: String? = null,
    val arabicVoice: Boolean = true,
    val trafficAvailable: Boolean = false,
    val reportsEnabled: Boolean = false,
)

class DarbViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)
    private val search = PhotonSearch()
    private val routing = OsrmRouting()
    private val reportsRepo = ReportsRepo(prefs)
    private val traffic = NoTraffic

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var engine: NavigationEngine? = null
    private var searchJob: Job? = null
    private var lastFixAt = 0L
    private var lastRerouteAt = 0L
    private var lastBounds: DoubleArray? = null
    private var gpsLostAnnounced = false
    private var arrivedHandled = false

    private val speaker = Speaker(app) { ar -> _state.update { it.copy(arabicVoice = ar) } }
    private val locationProvider = LocationProvider(
        app,
        onLocation = { onLocation(it) },
        onProviderState = { enabled -> _state.update { it.copy(gpsEnabled = enabled) } },
    )

    private val lang get() = _state.value.settings.lang
    fun t(ar: String, en: String) = if (lang == Lang.AR) ar else en

    init {
        _state.update {
            it.copy(
                settings = prefs.loadSettings(), favorites = prefs.favorites(), recents = prefs.recents(),
                trafficAvailable = traffic.available, reportsEnabled = reportsRepo.enabled,
            )
        }
        viewModelScope.launch {
            delay(1400)
            _state.update { it.copy(screen = Screen.MAP) }
        }
        viewModelScope.launch { tickLoop() }
    }

    // ---------------- housekeeping ----------------
    private suspend fun tickLoop() {
        var n = 0
        while (true) {
            delay(2000)
            n++
            val s = _state.value
            if (s.navigating && lastFixAt != 0L && SystemClock.elapsedRealtime() - lastFixAt > 10_000) {
                _state.update { it.copy(gpsLost = true) }
                if (!gpsLostAnnounced) {
                    gpsLostAnnounced = true
                    say(t("فُقدت إشارة الموقع", "GPS signal lost"))
                }
            }
            if (n % 15 == 0 && s.screen == Screen.MAP) lastBounds?.let { refreshReports(it) }
        }
    }

    fun toastShown() = _state.update { it.copy(toast = null) }
    private fun toast(msg: String) = _state.update { it.copy(toast = msg) }

    private fun netMsg(e: NetworkException): String = when (e.kind) {
        NetKind.OFFLINE -> t("لا يوجد اتصال بالإنترنت", "No internet connection")
        NetKind.TIMEOUT -> t("انتهت مهلة الاتصال، حاول مجدداً", "Connection timed out, try again")
        NetKind.RATE_LIMITED -> t("طلبات كثيرة، انتظر قليلاً", "Too many requests, please wait")
        NetKind.UNAUTHORIZED -> t("تعذّر التحقق من الجهاز", "Device could not be verified")
        NetKind.SERVER -> t("الخدمة غير متاحة حالياً", "Service is unavailable right now")
        NetKind.CLIENT -> t("تعذّر تنفيذ الطلب", "The request could not be completed")
    }

    private fun say(text: String) {
        if (_state.value.settings.muted) return
        speaker.speak(text, lang)
    }

    // ---------------- navigation between screens ----------------
    fun go(screen: Screen) = _state.update { it.copy(screen = screen) }

    // ---------------- permissions & location ----------------
    fun onPermission(granted: Boolean) {
        _state.update { it.copy(hasLocationPermission = granted) }
        if (granted) locationProvider.start(_state.value.navigating)
    }

    fun onResume() {
        val granted = locationProvider.hasPermission()
        _state.update { it.copy(hasLocationPermission = granted, gpsEnabled = locationProvider.isGpsEnabled()) }
        if (granted) locationProvider.start(_state.value.navigating)
    }

    fun onStop() {
        if (!_state.value.navigating) locationProvider.stop()
    }

    private fun onLocation(loc: Location) {
        if (_state.value.navigating && loc.hasAccuracy() && loc.accuracy > 150f) return // too poor for guidance
        lastFixAt = SystemClock.elapsedRealtime()
        gpsLostAnnounced = false
        val eng = engine
        var nav: NavState? = null
        if (eng != null && _state.value.navigating) {
            nav = eng.update(LatLng(loc.latitude, loc.longitude), if (loc.hasAccuracy()) loc.accuracy.toDouble() else 15.0, loc.speed.toDouble())
            nav.announcement?.let { say(it) }
            if (nav.arrived && !arrivedHandled) {
                arrivedHandled = true
                viewModelScope.launch {
                    delay(6000)
                    stopNavigation()
                }
            }
            if (nav.offRoute) rerouteFrom(loc)
        }
        _state.update { it.copy(myLocation = loc, gpsLost = false, nav = nav ?: it.nav) }
    }

    fun setFollowing(f: Boolean) = _state.update { it.copy(following = f) }

    // ---------------- search ----------------
    fun onQueryChange(q: String) {
        searchJob?.cancel()
        _state.update { it.copy(query = q, searchMessage = null) }
        if (q.trim().length < 2) {
            _state.update { it.copy(results = emptyList(), searching = false) }
            return
        }
        searchJob = viewModelScope.launch {
            delay(350)
            runSearch { search.search(q.trim(), focusPoint(), lang == Lang.AR) }
        }
    }

    fun searchCategory(category: String) {
        searchJob?.cancel()
        val center = focusPoint()
        if (center == null) {
            toast(t("فعّل الموقع أو حرّك الخريطة أولاً", "Enable location or move the map first"))
            return
        }
        _state.update { it.copy(query = "", screen = Screen.SEARCH) }
        searchJob = viewModelScope.launch { runSearch { search.nearby(category, center, lang == Lang.AR) } }
    }

    private suspend fun runSearch(block: suspend () -> List<Place>) {
        _state.update { it.copy(searching = true, searchMessage = null) }
        try {
            val r = block()
            _state.update {
                it.copy(results = r, searching = false,
                    searchMessage = if (r.isEmpty()) t("لا توجد نتائج مطابقة", "No matching results") else null)
            }
        } catch (e: NetworkException) {
            _state.update { it.copy(results = emptyList(), searching = false, searchMessage = netMsg(e)) }
        } catch (e: Exception) {
            _state.update { it.copy(results = emptyList(), searching = false, searchMessage = t("حدث خطأ أثناء البحث", "Search failed")) }
        }
    }

    private var mapCenter: LatLng? = null
    fun onMapCenter(c: LatLng) { mapCenter = c }
    private fun focusPoint(): LatLng? =
        _state.value.myLocation?.let { LatLng(it.latitude, it.longitude) } ?: mapCenter

    fun selectPlace(p: Place) {
        val recents = (listOf(p) + _state.value.recents.filter { it.id != p.id }).take(15)
        prefs.saveRecents(recents)
        _state.update {
            it.copy(selected = p, recents = recents, screen = Screen.MAP, routes = emptyList(), routeMessage = null,
                following = false, selectedReport = null)
        }
    }

    fun clearSelection() = _state.update { it.copy(selected = null, routes = emptyList(), routeMessage = null) }

    fun pickPoint(p: LatLng) {
        viewModelScope.launch {
            val place = try {
                search.reverse(p)
            } catch (e: Exception) {
                null
            } ?: Place("pt:${p.lat},${p.lon}", t("نقطة محددة على الخريطة", "Dropped pin"),
                "%.5f, %.5f".format(p.lat, p.lon), p.lat, p.lon)
            selectPlace(place)
        }
    }

    fun toggleFavorite(p: Place) {
        val cur = _state.value.favorites
        val next = if (cur.any { it.id == p.id }) cur.filter { it.id != p.id } else listOf(p) + cur
        prefs.saveFavorites(next)
        _state.update { it.copy(favorites = next) }
    }

    // ---------------- routing ----------------
    fun previewRoutes() {
        val dest = _state.value.selected ?: return
        val me = _state.value.myLocation
        if (me == null) {
            _state.update { it.copy(routeMessage = t("لم يتم تحديد موقعك بعد. فعّل GPS وامنح إذن الموقع.", "Your location is not available yet. Enable GPS and grant location permission.")) }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(routing = true, routeMessage = null) }
            try {
                val r = routing.routes(LatLng(me.latitude, me.longitude), dest.latLng, true)
                _state.update { it.copy(routes = r, routeIndex = 0, routing = false) }
            } catch (e: NetworkException) {
                _state.update { it.copy(routing = false, routeMessage = netMsg(e)) }
            } catch (e: RoutingException) {
                _state.update {
                    it.copy(routing = false, routeMessage = if (e.code == "NoRoute" || e.code == "NoSegment")
                        t("لا يوجد طريق بين موقعك والوجهة", "No road route between your location and the destination")
                    else t("تعذّر حساب المسار", "Could not compute a route"))
                }
            }
        }
    }

    fun selectRoute(i: Int) = _state.update { it.copy(routeIndex = i.coerceIn(0, (it.routes.size - 1).coerceAtLeast(0))) }

    fun startNavigation() {
        val s = _state.value
        val route = s.routes.getOrNull(s.routeIndex) ?: return
        engine = NavigationEngine(route, lang)
        arrivedHandled = false
        gpsLostAnnounced = false
        lastFixAt = SystemClock.elapsedRealtime()
        _state.update { it.copy(navigating = true, following = true, nav = null, routes = listOf(route), routeIndex = 0, gpsLost = false) }
        locationProvider.start(true)
        s.myLocation?.let { onLocation(it) }
    }

    fun stopNavigation() {
        engine = null
        speaker.stop()
        _state.update { it.copy(navigating = false, nav = null, routes = emptyList(), rerouting = false, gpsLost = false) }
        locationProvider.start(false)
    }

    private fun rerouteFrom(loc: Location) {
        val dest = _state.value.selected ?: return
        val now = SystemClock.elapsedRealtime()
        if (_state.value.rerouting || now - lastRerouteAt < 8000) return
        lastRerouteAt = now
        viewModelScope.launch {
            _state.update { it.copy(rerouting = true) }
            say(t("خرجت عن المسار، جارٍ إعادة الحساب", "Off route, recalculating"))
            try {
                val r = routing.routes(LatLng(loc.latitude, loc.longitude), dest.latLng, false).first()
                engine = NavigationEngine(r, lang)
                _state.update { it.copy(routes = listOf(r), routeIndex = 0, rerouting = false) }
                say(t("تمت إعادة حساب المسار", "Route updated"))
            } catch (e: Exception) {
                _state.update { it.copy(rerouting = false) }
                toast(t("تعذّرت إعادة حساب المسار. تحقق من الاتصال.", "Could not recalculate the route. Check your connection."))
            }
        }
    }

    // ---------------- community reports ----------------
    fun openReportSheet(open: Boolean) = _state.update { it.copy(reportSheet = open) }

    fun onMapBounds(minLon: Double, minLat: Double, maxLon: Double, maxLat: Double) {
        lastBounds = doubleArrayOf(minLon, minLat, maxLon, maxLat)
        refreshReports(lastBounds!!)
    }

    private fun refreshReports(b: DoubleArray) {
        if (!reportsRepo.enabled) return
        viewModelScope.launch {
            try {
                val list = reportsRepo.list(b[0], b[1], b[2], b[3])
                _state.update { it.copy(reports = list) }
            } catch (e: Exception) {
                // keep showing the last known reports; do not spam the driver with errors
            }
        }
    }

    fun submitReport(type: ReportType) {
        val me = _state.value.myLocation
        if (!reportsRepo.enabled) {
            toast(t("خادم البلاغات غير مُعدّ في هذه النسخة", "The reports server is not configured in this build"))
            return
        }
        if (me == null) {
            toast(t("لا يمكن إرسال البلاغ دون تحديد موقعك", "Cannot send a report without your location"))
            return
        }
        _state.update { it.copy(reportSheet = false) }
        viewModelScope.launch {
            try {
                val r = reportsRepo.create(type, LatLng(me.latitude, me.longitude))
                if (r != null) _state.update { s -> s.copy(reports = s.reports.filter { it.id != r.id } + r) }
                toast(t("تم إرسال البلاغ، شكراً لك", "Report sent, thank you"))
            } catch (e: NetworkException) {
                toast(
                    if (e.kind == NetKind.RATE_LIMITED) t("أرسلت بلاغات كثيرة، انتظر قليلاً", "You are sending too many reports, wait a moment")
                    else t("فشل إرسال البلاغ: ", "Report failed: ") + netMsg(e)
                )
            }
        }
    }

    fun selectReport(id: String?) = _state.update { s -> s.copy(selectedReport = id?.let { rid -> s.reports.firstOrNull { it.id == rid } }) }

    fun voteReport(id: String, confirm: Boolean) {
        viewModelScope.launch {
            try {
                val r = reportsRepo.vote(id, confirm)
                _state.update { s ->
                    s.copy(
                        reports = if (r == null || r.status != "active") s.reports.filter { it.id != id }
                        else s.reports.map { if (it.id == id) r else it },
                        selectedReport = null,
                    )
                }
                toast(t("شكراً، تم تسجيل رأيك", "Thanks, your vote was recorded"))
            } catch (e: NetworkException) {
                val msg = when {
                    e.status == 403 -> t("لا يمكنك التصويت على بلاغك أنت", "You cannot vote on your own report")
                    e.status == 409 || e.status == 404 -> t("هذا البلاغ لم يعد فعّالاً", "This report is no longer active")
                    else -> netMsg(e)
                }
                _state.update { it.copy(selectedReport = null) }
                toast(msg)
            }
        }
    }

    // ---------------- settings ----------------
    private fun saveSettings(s: Settings) {
        prefs.saveSettings(s)
        _state.update { it.copy(settings = s) }
    }

    fun setTheme(t: ThemeMode) = saveSettings(_state.value.settings.copy(theme = t))
    fun setLang(l: Lang) = saveSettings(_state.value.settings.copy(lang = l))
    fun toggleMute() {
        val s = _state.value.settings.copy(muted = !_state.value.settings.muted)
        if (s.muted) speaker.stop()
        saveSettings(s)
    }
    fun toggle3d() = saveSettings(_state.value.settings.copy(buildings3d = !_state.value.settings.buildings3d))

    override fun onCleared() {
        locationProvider.stop()
        speaker.shutdown()
    }
}
