package iq.darb.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.mutableStateOf
import iq.darb.app.core.Format
import iq.darb.app.core.Instructions
import iq.darb.app.core.Lang
import iq.darb.app.core.Report
import iq.darb.app.core.ReportType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun arrowFor(type: String?, modifier: String?): String = when {
    type == "arrive" -> "🏁"
    type == "roundabout" || type == "rotary" -> "🔄"
    modifier == "uturn" -> "↩️"
    modifier == "right" -> "➡️"
    modifier == "left" -> "⬅️"
    modifier == "slight right" -> "↗️"
    modifier == "slight left" -> "↖️"
    modifier == "sharp right" -> "↘️"
    modifier == "sharp left" -> "↙️"
    else -> "⬆️"
}

@Composable
private fun RoundButton(label: String, onClick: () -> Unit, container: Color = MaterialTheme.colorScheme.surface, size: Int = 52) {
    Surface(
        onClick = onClick, shape = CircleShape, color = container, shadowElevation = 6.dp,
        modifier = Modifier.size(size.dp),
    ) { Box(contentAlignment = Alignment.Center) { Text(label, fontSize = 22.sp) } }
}

@Composable
private fun Banner(text: String, color: Color, onClick: (() -> Unit)? = null, action: String? = null) {
    Surface(color = color, shape = RoundedCornerShape(14.dp), shadowElevation = 4.dp, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(text, Modifier.weight(1f), color = Color.White, fontSize = 14.sp)
            if (action != null && onClick != null) TextButton(onClick = onClick) { Text(action, color = Accent, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
fun MapScreen(state: UiState, vm: DarbViewModel, requestPermission: () -> Unit, openLocationSettings: () -> Unit) {
    val night = LocalNight.current
    val lang = LocalLang.current
    var northNonce by remember { mutableIntStateOf(0) }

    LaunchedEffect(state.toast) {
        if (state.toast != null) {
            kotlinx.coroutines.delay(3200)
            vm.toastShown()
        }
    }

    Box(Modifier.fillMaxSize()) {
        DarbMap(
            Modifier.fillMaxSize(),
            MapInput(
                night = night, lang = lang, buildings3d = state.settings.buildings3d,
                location = state.myLocation, permission = state.hasLocationPermission,
                following = state.following, navigating = state.navigating,
                navBearing = state.nav?.bearing?.toFloat(),
                routes = state.routes, routeIndex = state.routeIndex,
                destination = state.selected, reports = state.reports, northResetNonce = northNonce,
            ),
            MapCallbacks(
                onLongPress = { vm.pickPoint(it) },
                onReportTap = { vm.selectReport(it) },
                onUserGesture = { vm.setFollowing(false) },
                onBounds = { a, b, c, d -> vm.onMapBounds(a, b, c, d) },
                onCenter = { vm.onMapCenter(it) },
            ),
        )

        // ---------- top area ----------
        Column(Modifier.fillMaxWidth().statusBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (state.navigating) {
                NavBanner(state)
            } else {
                Surface(
                    onClick = { vm.go(Screen.SEARCH) }, shape = RoundedCornerShape(28.dp),
                    color = MaterialTheme.colorScheme.surface, shadowElevation = 8.dp, modifier = Modifier.fillMaxWidth().height(54.dp),
                ) {
                    Row(Modifier.padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🔍", fontSize = 20.sp)
                        Spacer(Modifier.width(12.dp))
                        Text(tr("إلى أين؟", "Where to?"), fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            if (!state.hasLocationPermission)
                Banner(tr("اسمح بالوصول إلى الموقع لتحديد موقعك وبدء الملاحة", "Allow location access to see where you are and navigate"),
                    Color(0xCC37474F), requestPermission, tr("السماح", "Allow"))
            else if (!state.gpsEnabled)
                Banner(tr("خدمة تحديد الموقع (GPS) متوقفة", "Location services (GPS) are off"), Color(0xCCB26A00), openLocationSettings, tr("تشغيل", "Turn on"))
            if (state.gpsLost && state.navigating)
                Banner(tr("إشارة GPS ضعيفة أو مفقودة… سيستمر التطبيق بمحاولة تحديد موقعك", "GPS signal weak or lost… still trying to find your position"), Color(0xCCB71C1C))
            if (state.rerouting)
                Banner(tr("جارٍ إعادة حساب المسار…", "Recalculating route…"), Color(0xCC1565C0))
            state.toast?.let { Banner(it, Color(0xEE263238)) }
        }

        // ---------- side buttons ----------
        Column(
            Modifier.align(Alignment.BottomEnd).padding(end = 12.dp, bottom = if (state.navigating) 120.dp else if (state.selected != null) 260.dp else 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            RoundButton("🧭", { northNonce++ })
            RoundButton(if (state.following) "🎯" else "📍", {
                if (!state.hasLocationPermission) requestPermission() else vm.setFollowing(true)
            })
        }
        Box(
            Modifier.align(Alignment.BottomStart).padding(start = 12.dp, bottom = if (state.navigating) 120.dp else if (state.selected != null) 260.dp else 16.dp)
        ) { RoundButton("⚠️", { vm.openReportSheet(true) }, container = Accent, size = 62) }

        // ---------- bottom area ----------
        Box(Modifier.align(Alignment.BottomCenter)) {
            when {
                state.navigating -> NavBottomBar(state, vm)
                state.selected != null -> DestinationCard(state, vm)
            }
        }

        // ---------- report overlays ----------
        if (state.reportSheet) ReportSheet(vm)
        state.selectedReport?.let { ReportDetail(it, vm) }
    }
}

@Composable
private fun NavBanner(state: UiState) {
    val lang = LocalLang.current
    val nav = state.nav
    val next = nav?.nextStep
    Surface(color = Navy, shape = RoundedCornerShape(20.dp), shadowElevation = 10.dp, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(arrowFor(next?.type, next?.modifier), fontSize = 40.sp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                if (nav == null) {
                    Text(tr("جارٍ تحديد موقعك…", "Finding your position…"), color = Color.White, fontSize = 18.sp)
                } else {
                    Text(Format.distance(nav.distanceToNextM, lang), color = Accent, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text(
                        if (next != null) Instructions.core(next, lang) else tr("تابع حتى الوجهة", "Continue to your destination"),
                        color = Color.White, fontSize = 17.sp, maxLines = 2,
                    )
                }
            }
        }
    }
}

@Composable
private fun NavBottomBar(state: UiState, vm: DarbViewModel) {
    val lang = LocalLang.current
    val nav = state.nav
    val eta = nav?.let {
        SimpleDateFormat("hh:mm a", if (lang == Lang.AR) Locale("ar") else Locale.ENGLISH)
            .format(Date(System.currentTimeMillis() + (it.remainingSec * 1000).toLong()))
    }
    Surface(color = Navy, shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp), shadowElevation = 12.dp, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                if (nav != null) {
                    Text(Format.duration(nav.remainingSec, lang), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("${Format.distance(nav.remainingM, lang)}  ·  ${tr("وصول", "ETA")} $eta", color = Color(0xFFC7D2EA), fontSize = 14.sp)
                    if (nav.arrived) Text(tr("وصلت إلى وجهتك", "You have arrived"), color = Accent, fontSize = 14.sp)
                } else Text("…", color = Color.White)
            }
            RoundButton(if (state.settings.muted) "🔇" else "🔊", { vm.toggleMute() }, container = Color(0xFF223562), size = 48)
            Spacer(Modifier.width(10.dp))
            Button(
                onClick = { vm.stopNavigation() },
                colors = ButtonDefaults.buttonColors(containerColor = Danger, contentColor = Color.White),
                shape = RoundedCornerShape(16.dp),
            ) { Text(tr("إنهاء", "End"), fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun DestinationCard(state: UiState, vm: DarbViewModel) {
    val lang = LocalLang.current
    val place = state.selected ?: return
    val fav = state.favorites.any { it.id == place.id }
    Surface(
        color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        shadowElevation = 12.dp, modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(place.name, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 2)
                    if (place.subtitle.isNotBlank()) Text(place.subtitle, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                }
                TextButton(onClick = { vm.toggleFavorite(place) }) { Text(if (fav) "★" else "☆", fontSize = 28.sp, color = Accent) }
                TextButton(onClick = { vm.clearSelection() }) { Text("✕", fontSize = 20.sp) }
            }
            when {
                state.routing -> Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.5.dp)
                    Spacer(Modifier.width(10.dp)); Text(tr("جارٍ حساب المسار…", "Calculating route…"))
                }
                state.routes.isEmpty() -> {
                    state.routeMessage?.let { Text(it, color = Danger, fontSize = 14.sp) }
                    Button(onClick = { vm.previewRoutes() }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
                        Text(tr("المسارات", "Directions"), fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    }
                }
                else -> {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        state.routes.forEachIndexed { i, r ->
                            val sel = i == state.routeIndex
                            Surface(
                                onClick = { vm.selectRoute(i) }, shape = RoundedCornerShape(16.dp),
                                color = if (sel) Blue else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (sel) Color.White else MaterialTheme.colorScheme.onSurface,
                            ) {
                                Column(Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
                                    Text(Format.duration(r.duration, lang), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                    Text(
                                        Format.distance(r.distance, lang) + if (i == 0) "  ·  " + tr("الأسرع", "Fastest") else "  ·  " + tr("بديل", "Alt"),
                                        fontSize = 12.sp,
                                    )
                                }
                            }
                        }
                    }
                    Text(
                        tr("الوقت تقدير من بيانات الطرق ولا يشمل الزحام المباشر.", "Time is estimated from road data and excludes live traffic."),
                        fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Button(
                        onClick = { vm.startNavigation() }, modifier = Modifier.fillMaxWidth().height(54.dp),
                        shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Ok, contentColor = Color.White),
                    ) { Text(tr("ابدأ الرحلة", "Start trip"), fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}

@Composable
private fun ReportSheet(vm: DarbViewModel) {
    val lang = LocalLang.current
    Box(Modifier.fillMaxSize().background(Color(0x99000000)).clickable { vm.openReportSheet(false) }) {
        Surface(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().clickable(enabled = false) {},
            color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(tr("ماذا تريد أن تبلّغ عنه؟", "What do you want to report?"), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(
                    tr("سلامتك أولاً: لا تستخدم الهاتف أثناء القيادة، اطلب من مرافقك الإبلاغ.", "Safety first: do not use your phone while driving; ask a passenger to report."),
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                ReportType.entries.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        row.forEach { t ->
                            Surface(
                                onClick = { vm.submitReport(t) }, shape = RoundedCornerShape(18.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.weight(1f).height(92.dp),
                            ) {
                                Column(Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                    Text(t.emoji, fontSize = 30.sp)
                                    Text(t.label(lang), fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 2)
                                }
                            }
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
                OutlinedButton(onClick = { vm.openReportSheet(false) }, modifier = Modifier.fillMaxWidth()) { Text(tr("إلغاء", "Cancel")) }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun ReportDetail(r: Report, vm: DarbViewModel) {
    val lang = LocalLang.current
    val ageMin = ((System.currentTimeMillis() / 1000 - r.createdAt) / 60).coerceAtLeast(0)
    Box(Modifier.fillMaxSize().background(Color(0x66000000)).clickable { vm.selectReport(null) }) {
        Surface(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().clickable(enabled = false) {},
            color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(r.type.emoji, fontSize = 34.sp)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(r.type.label(lang), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text(
                            if (r.verified) tr("مؤكد من ${r.confirmations} مستخدمين", "Confirmed by ${r.confirmations} users")
                            else tr("غير مؤكد بعد", "Not yet confirmed"),
                            fontSize = 13.sp, color = if (r.verified) Ok else Color(0xFFFFA000),
                        )
                    }
                }
                Text(
                    tr("قبل $ageMin دقيقة", "$ageMin min ago") + (r.note?.let { " · $it" } ?: ""),
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (r.unverifiedSensitive)
                    Text(
                        tr("هذا البلاغ لم يؤكده مستخدمون آخرون، فلا تعتمد عليه كحقيقة مؤكدة.", "No other user has confirmed this report; do not treat it as fact."),
                        fontSize = 12.sp, color = Color(0xFFFFA000),
                    )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { vm.voteReport(r.id, true) }, modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Ok, contentColor = Color.White),
                    ) { Text(tr("ما زال موجوداً", "Still there")) }
                    Button(
                        onClick = { vm.voteReport(r.id, false) }, modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Danger, contentColor = Color.White),
                    ) { Text(tr("لم يعد موجوداً", "Gone")) }
                }
                Spacer(Modifier.height(6.dp))
            }
        }
    }
}
