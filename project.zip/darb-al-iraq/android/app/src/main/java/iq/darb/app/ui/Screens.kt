package iq.darb.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import iq.darb.app.core.Lang
import iq.darb.app.core.Place
import iq.darb.app.data.ThemeMode

@Composable
fun SplashScreen() {
    Box(Modifier.fillMaxSize().background(Navy), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🛣️", fontSize = 64.sp)
            Spacer(Modifier.height(12.dp))
            Text("درب العراق", color = Accent, fontSize = 40.sp, fontWeight = FontWeight.Bold)
            Text("Darb Al-Iraq", color = androidx.compose.ui.graphics.Color.White, fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
            Text("ملاحتك بلمسة عراقية", color = androidx.compose.ui.graphics.Color(0xFFC7D2EA), fontSize = 16.sp)
            Spacer(Modifier.height(32.dp))
            CircularProgressIndicator(color = Accent, modifier = Modifier.size(28.dp), strokeWidth = 3.dp)
        }
    }
}

@Composable
fun PlaceRow(place: Place, isFavorite: Boolean, onClick: () -> Unit, onToggleFavorite: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("📍", fontSize = 22.sp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(place.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1)
            if (place.subtitle.isNotBlank())
                Text(place.subtitle, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
        }
        if (onToggleFavorite != null) {
            TextButton(onClick = onToggleFavorite) { Text(if (isFavorite) "★" else "☆", fontSize = 24.sp, color = Accent) }
        }
    }
}

@Composable
fun SearchScreen(state: UiState, vm: DarbViewModel) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { vm.go(Screen.MAP) }) { Text("✕", fontSize = 20.sp) }
            OutlinedTextField(
                value = state.query,
                onValueChange = vm::onQueryChange,
                modifier = Modifier.weight(1f).focusRequester(focus),
                placeholder = { Text(tr("ابحث عن مدينة، شارع، مكان…", "Search city, street, place…")) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { vm.onQueryChange(state.query) }),
                shape = RoundedCornerShape(16.dp),
            )
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val cats = listOf(
                Triple("fuel", "⛽", tr("وقود", "Fuel")), Triple("hospital", "🏥", tr("مستشفيات", "Hospitals")),
                Triple("pharmacy", "💊", tr("صيدليات", "Pharmacies")), Triple("restaurant", "🍽️", tr("مطاعم", "Restaurants")),
                Triple("supermarket", "🛒", tr("متاجر", "Shops")),
            )
            for ((id, icon, label) in cats) {
                Surface(
                    onClick = { vm.searchCategory(id) }, shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                ) { Text("$icon  $label", Modifier.padding(horizontal = 14.dp, vertical = 8.dp), fontSize = 14.sp) }
            }
        }
        Spacer(Modifier.height(8.dp))
        when {
            state.searching -> Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            state.searchMessage != null -> Text(
                state.searchMessage, Modifier.fillMaxWidth().padding(32.dp), textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            state.results.isNotEmpty() -> LazyColumn {
                items(state.results, key = { it.id + it.lat + it.lon }) { p ->
                    PlaceRow(p, state.favorites.any { it.id == p.id }, { vm.selectPlace(p) }, { vm.toggleFavorite(p) })
                    HorizontalDivider()
                }
            }
            else -> LazyColumn {
                if (state.favorites.isNotEmpty()) {
                    item { SectionTitle(tr("المواقع المحفوظة", "Saved places")) }
                    items(state.favorites.take(5), key = { "f" + it.id }) { p ->
                        PlaceRow(p, true, { vm.selectPlace(p) }, { vm.toggleFavorite(p) }); HorizontalDivider()
                    }
                }
                if (state.recents.isNotEmpty()) {
                    item { SectionTitle(tr("عمليات البحث الأخيرة", "Recent searches")) }
                    items(state.recents, key = { "r" + it.id }) { p ->
                        PlaceRow(p, state.favorites.any { it.id == p.id }, { vm.selectPlace(p) }, { vm.toggleFavorite(p) }); HorizontalDivider()
                    }
                }
                if (state.favorites.isEmpty() && state.recents.isEmpty()) item {
                    Text(
                        tr("اكتب اسم مكان للبدء. يمكنك أيضاً الضغط مطولاً على الخريطة لاختيار وجهة.", "Type a place name to start. You can also long-press the map to pick a destination."),
                        Modifier.fillMaxWidth().padding(32.dp), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, Modifier.padding(horizontal = 16.dp, vertical = 8.dp), fontWeight = FontWeight.Bold, color = Accent, fontSize = 14.sp)
}

@Composable
fun FavoritesScreen(state: UiState, vm: DarbViewModel) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding()) {
        Text(tr("المفضلة", "Favorites"), Modifier.padding(16.dp), fontSize = 24.sp, fontWeight = FontWeight.Bold)
        if (state.favorites.isEmpty()) {
            Text(
                tr("لا توجد مواقع محفوظة بعد. افتح أي مكان واضغط ☆ لإضافته.", "No saved places yet. Open any place and tap ☆ to save it."),
                Modifier.fillMaxWidth().padding(32.dp), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else LazyColumn {
            items(state.favorites, key = { it.id }) { p ->
                PlaceRow(p, true, { vm.selectPlace(p) }, { vm.toggleFavorite(p) }); HorizontalDivider()
            }
        }
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String? = null, trailing: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp)
            if (subtitle != null) Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        trailing()
    }
}

@Composable
private fun Choice(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick, shape = RoundedCornerShape(18.dp),
        color = if (selected) Accent else MaterialTheme.colorScheme.surfaceVariant,
        contentColor = if (selected) Navy else MaterialTheme.colorScheme.onSurface,
        border = if (selected) null else BorderStroke(1.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f)),
    ) { Text(label, Modifier.padding(horizontal = 14.dp, vertical = 8.dp), fontSize = 14.sp) }
}

@Composable
fun SettingsScreen(state: UiState, vm: DarbViewModel) {
    val s = state.settings
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding().verticalScroll(rememberScrollState())) {
        Text(tr("الإعدادات", "Settings"), Modifier.padding(16.dp), fontSize = 24.sp, fontWeight = FontWeight.Bold)

        SettingRow(tr("اللغة", "Language")) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Choice("العربية", s.lang == Lang.AR) { vm.setLang(Lang.AR) }
                Choice("English", s.lang == Lang.EN) { vm.setLang(Lang.EN) }
            }
        }
        HorizontalDivider()
        SettingRow(tr("المظهر", "Appearance")) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Choice(tr("النظام", "System"), s.theme == ThemeMode.SYSTEM) { vm.setTheme(ThemeMode.SYSTEM) }
                Choice(tr("نهاري", "Day"), s.theme == ThemeMode.DAY) { vm.setTheme(ThemeMode.DAY) }
                Choice(tr("ليلي", "Night"), s.theme == ThemeMode.NIGHT) { vm.setTheme(ThemeMode.NIGHT) }
            }
        }
        HorizontalDivider()
        SettingRow(
            tr("كتم التوجيه الصوتي", "Mute voice guidance"),
            if (!state.arabicVoice && s.lang == Lang.AR) tr("لم يُعثر على صوت عربي في جهازك. ثبّت بيانات الصوت العربي من إعدادات النص إلى كلام.", "No Arabic voice found. Install Arabic voice data in your device's text-to-speech settings.") else null,
        ) { Switch(checked = s.muted, onCheckedChange = { vm.toggleMute() }) }
        HorizontalDivider()
        SettingRow(tr("المباني ثلاثية الأبعاد", "3D buildings"), tr("تظهر عند توفر بياناتها في الخريطة", "Shown where map data has building heights")) {
            Switch(checked = s.buildings3d, onCheckedChange = { vm.toggle3d() })
        }
        HorizontalDivider()
        SectionTitle(tr("حالة الخدمات", "Service status"))
        SettingRow(
            tr("بيانات الزحام المباشر", "Live traffic data"),
            if (state.trafficAvailable) null else tr("غير متاحة: لا يوجد مزود مجاني يغطي العراق. تعتمد الحالة على البلاغات المجتمعية فقط.", "Not available: no free provider covers Iraq. Conditions rely on community reports only."),
        ) { Text(if (state.trafficAvailable) "✓" else "—") }
        SettingRow(
            tr("خادم البلاغات المجتمعية", "Community reports server"),
            if (state.reportsEnabled) null else tr("غير مُعدّ في هذه النسخة (DARB_REPORTS_URL).", "Not configured in this build (DARB_REPORTS_URL)."),
        ) { Text(if (state.reportsEnabled) "✓" else "—") }
        HorizontalDivider()
        SectionTitle(tr("حول", "About"))
        Text(
            tr("درب العراق — ملاحتك بلمسة عراقية\nالإصدار 0.1.0\nبيانات الخريطة © مساهمو OpenStreetMap.\nالبلاغات المجتمعية غير مؤكدة ما لم تُؤكَّد من مستخدمين آخرين. التزم بقوانين المرور ولا تستخدم الهاتف أثناء القيادة.",
                "Darb Al-Iraq — navigation with an Iraqi touch\nVersion 0.1.0\nMap data © OpenStreetMap contributors.\nCommunity reports are unverified until confirmed by other users. Obey traffic laws and do not use your phone while driving."),
            Modifier.padding(16.dp), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(24.dp))
    }
}
