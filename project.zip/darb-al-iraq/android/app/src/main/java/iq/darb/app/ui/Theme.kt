package iq.darb.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import iq.darb.app.core.Lang
import iq.darb.app.data.ThemeMode

val Navy = Color(0xFF0E1A33)
val NavyCard = Color(0xFF17284A)
val Accent = Color(0xFFFFC83D)
val Blue = Color(0xFF3D8BFF)
val Danger = Color(0xFFE53935)
val Ok = Color(0xFF2E7D32)

val LocalLang = compositionLocalOf { Lang.AR }
val LocalNight = compositionLocalOf { true }

@Composable
fun tr(ar: String, en: String): String = if (LocalLang.current == Lang.AR) ar else en

@Composable
fun DarbTheme(mode: ThemeMode, lang: Lang, content: @Composable () -> Unit) {
    val night = when (mode) {
        ThemeMode.NIGHT -> true
        ThemeMode.DAY -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val scheme = if (night) darkColorScheme(
        primary = Accent, onPrimary = Navy, background = Navy, onBackground = Color.White,
        surface = NavyCard, onSurface = Color.White, secondary = Blue, error = Danger,
        surfaceVariant = Color(0xFF223562), onSurfaceVariant = Color(0xFFC7D2EA),
    ) else lightColorScheme(
        primary = Color(0xFF0E1A33), onPrimary = Color.White, background = Color(0xFFF2F5FA), onBackground = Navy,
        surface = Color.White, onSurface = Navy, secondary = Blue, error = Danger,
        surfaceVariant = Color(0xFFE3E9F4), onSurfaceVariant = Color(0xFF3A4766),
    )
    CompositionLocalProvider(
        LocalLang provides lang,
        LocalNight provides night,
        LocalLayoutDirection provides if (lang == Lang.AR) LayoutDirection.Rtl else LayoutDirection.Ltr,
    ) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
