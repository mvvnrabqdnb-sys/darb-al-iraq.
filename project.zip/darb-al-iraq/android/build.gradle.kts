// Versions were chosen from memory and NOT verified against Maven (no network in the authoring sandbox).
// If Gradle sync reports a missing version, bump to the nearest available release.
plugins {
    id("com.android.application") version "8.9.1" apply false
    id("org.jetbrains.kotlin.android") version "2.1.20" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.1.20" apply false
}
