import iq.darb.app.core.*

// Standalone verification of the pure-Kotlin core (no Android needed).
// NOTE: the OSRM JSON below is a HAND-WRITTEN fixture shaped like an OSRM response.
// It is NOT a captured response from a real routing server.

var failures = 0
var checks = 0
fun check(name: String, ok: Boolean, detail: String = "") {
    checks++
    if (ok) println("PASS  $name") else { failures++; println("FAIL  $name $detail") }
}

fun line(a: LatLng, b: LatLng, stepM: Double): String {
    val n = maxOf(1, (Geo.distance(a, b) / stepM).toInt())
    return (0..n).joinToString(",") { i ->
        val t = i.toDouble() / n
        "[${a.lon + (b.lon - a.lon) * t},${a.lat + (b.lat - a.lat) * t}]"
    }
}

fun fixture(): String {
    val a = LatLng(33.3000, 44.3000)
    val b = LatLng(33.3000, 44.3400)
    val c = LatLng(33.3100, 44.3400)
    val d1 = Geo.distance(a, b); val d2 = Geo.distance(b, c)
    return """
    {"code":"Ok","routes":[{"distance":${d1 + d2},"duration":${(d1 + d2) / 12.0},"legs":[{"steps":[
      {"distance":$d1,"duration":${d1 / 12.0},"name":"شارع الرشيد","maneuver":{"type":"depart","location":[${a.lon},${a.lat}]},"geometry":{"coordinates":[${line(a, b, 100.0)}]}},
      {"distance":$d2,"duration":${d2 / 12.0},"name":"شارع فلسطين","maneuver":{"type":"turn","modifier":"left","location":[${b.lon},${b.lat}]},"geometry":{"coordinates":[${line(b, c, 100.0)}]}},
      {"distance":0,"duration":0,"name":"","maneuver":{"type":"arrive","modifier":"right","location":[${c.lon},${c.lat}]},"geometry":{"coordinates":[[${c.lon},${c.lat}],[${c.lon},${c.lat}]]}}
    ]}]}]}"""
}

fun main(args: Array<String>) {
    extraChecks(args)
    // ---- Geo ----
    val baghdad = LatLng(33.3152, 44.3661); val basra = LatLng(30.5085, 47.7835)
    val dkm = Geo.distance(baghdad, basra) / 1000
    check("haversine Baghdad-Basra ~448km", dkm in 440.0..456.0, "got $dkm")
    check("angleDiff wraps (350 vs 10 = 20)", Math.abs(Geo.angleDiff(350.0, 10.0) - 20.0) < 1e-9)
    check("bearing due east ~90", Math.abs(Geo.bearing(LatLng(33.0, 44.0), LatLng(33.0, 44.1)) - 90.0) < 0.2)
    val pr = Geo.project(LatLng(33.0009, 44.05), LatLng(33.0, 44.0), LatLng(33.0, 44.1))
    check("projection distance ~100m", pr.distanceM in 95.0..105.0, "got ${pr.distanceM}")

    // ---- Parser ----
    val routes = OsrmParser.parse(fixture())
    val route = routes[0]
    check("parser: 3 steps", route.steps.size == 3, "got ${route.steps.size}")
    check("parser: types depart/turn/arrive", route.steps.map { it.type } == listOf("depart", "turn", "arrive"))
    check("parser: geometry spans both legs", route.geometry.size > 40, "got ${route.geometry.size}")
    check("parser: step 2 starts where step 1 ends", Geo.distance(route.geometry[route.steps[1].startIndex], route.steps[1].location) < 1.0)
    check("parser: Arabic name preserved", route.steps[0].name == "شارع الرشيد")
    val err = try { OsrmParser.parse("""{"code":"NoRoute","message":"Impossible route"}"""); null } catch (e: RoutingException) { e }
    check("parser: NoRoute raises RoutingException", err?.code == "NoRoute")
    val bad = try { OsrmParser.parse("<html>502</html>"); null } catch (e: RoutingException) { e }
    check("parser: garbage -> BadResponse", bad?.code == "BadResponse")

    // ---- Instructions (Arabic) ----
    val turnR = RouteStep("turn", "right", "شارع الرشيد", 0.0, 0.0, null, LatLng(0.0, 0.0), 0)
    check("AR turn right", Instructions.text(turnR, Lang.AR) == "انعطف يميناً إلى شارع الرشيد", Instructions.text(turnR, Lang.AR))
    check("AR distance prefix", Instructions.text(turnR.copy(modifier = "left", name = ""), Lang.AR, 300.0) == "بعد 300 متر، انعطف يساراً",
        Instructions.text(turnR.copy(modifier = "left", name = ""), Lang.AR, 300.0))
    val rb = RouteStep("roundabout", "right", "", 0.0, 0.0, 2, LatLng(0.0, 0.0), 0)
    check("AR roundabout exit 2", Instructions.text(rb, Lang.AR) == "ادخل الدوّار وخذ المخرج الثاني", Instructions.text(rb, Lang.AR))
    val arr = RouteStep("arrive", "left", "", 0.0, 0.0, null, LatLng(0.0, 0.0), 0)
    check("AR arrive left", Instructions.text(arr, Lang.AR) == "وصلت إلى وجهتك، الوجهة على اليسار", Instructions.text(arr, Lang.AR))
    check("EN turn left", Instructions.text(turnR.copy(modifier = "left", name = "Palestine St"), Lang.EN) == "turn left onto Palestine St")
    check("AR 1.5km spoken", Format.spokenDistance(1500.0, Lang.AR) == "بعد 1.5 كيلومتر", Format.spokenDistance(1500.0, Lang.AR))
    check("duration 80min AR", Format.duration(4800.0, Lang.AR) == "1 س 20 د", Format.duration(4800.0, Lang.AR))
    check("distance 3.2km AR", Format.distance(3200.0, Lang.AR) == "3.2 كم", Format.distance(3200.0, Lang.AR))

    // ---- Engine: simulate a drive with GPS noise ----
    val engine = NavigationEngine(route, Lang.AR)
    val rnd = java.util.Random(42)
    val total = Geo.polylineLength(route.geometry)
    val ann = ArrayList<String>()
    var prevRemaining = Double.MAX_VALUE
    var monotonic = true
    var arrived = false
    var falseOff = false
    var d = 0.0
    var first: NavState? = null
    while (d <= total + 10) {
        val p = pointAt(route.geometry, minOf(d, total))
        val noisy = LatLng(p.lat + (rnd.nextGaussian() * 4.0) / 111000.0, p.lon + (rnd.nextGaussian() * 4.0) / 93000.0)
        val st = engine.update(noisy, 8.0, 12.0)
        if (first == null) first = st
        if (st.offRoute) falseOff = true
        if (st.remainingM > prevRemaining + 45.0) monotonic = false
        prevRemaining = minOf(prevRemaining, st.remainingM)
        st.announcement?.let { ann.add(it) }
        if (st.arrived) arrived = true
        d += 12.0
    }
    println("announcements: $ann")
    check("engine: start remaining ~ route length", Math.abs(first!!.remainingM - total) < 40.0)
    check("engine: remaining never grows materially", monotonic)
    check("engine: no false off-route with 4m noise", !falseOff)
    check("engine: announces depart first", ann.firstOrNull()?.startsWith("انطلق") == true, "first=${ann.firstOrNull()}")
    check("engine: announces the left turn", ann.any { it.contains("انعطف يساراً إلى شارع فلسطين") })
    check("engine: advance warning includes distance", ann.any { it.startsWith("بعد") && it.contains("انعطف يساراً") })
    check("engine: arrival announced once", ann.count { it.startsWith("وصلت") } == 1, "count=${ann.count { it.startsWith("وصلت") }}")
    check("engine: no duplicate announcements", ann.size == ann.toSet().size, "ann=$ann")
    check("engine: arrived at end", arrived)

    // ---- Engine: off-route detection and recovery ----
    val e2 = NavigationEngine(route, Lang.AR)
    val mid = pointAt(route.geometry, total * 0.3)
    e2.update(mid, 8.0, 12.0)
    val far = LatLng(mid.lat + 250.0 / 111000.0, mid.lon)
    val s1 = e2.update(far, 8.0, 12.0); val s2 = e2.update(far, 8.0, 12.0); val s3 = e2.update(far, 8.0, 12.0)
    check("off-route: not flagged on 1st/2nd far fix", !s1.offRoute && !s2.offRoute)
    check("off-route: flagged on 3rd consecutive far fix", s3.offRoute)
    check("off-route: distance reported ~250m", s3.distanceFromRouteM in 230.0..270.0, "got ${s3.distanceFromRouteM}")
    check("off-route: no spoken instruction while off route", s3.announcement == null)
    val back = e2.update(mid, 8.0, 12.0)
    check("off-route: clears when back on route", !back.offRoute)

    println("\n$checks checks, $failures failures")
    if (failures > 0) System.exit(1)
}

fun extraChecks(args: Array<String>) {
    // ---- Arabic normalization / ranking ----
    check("normalize: أربيل == اربيل", ArabicText.normalize("أربيل") == ArabicText.normalize("اربيل"))
    check("normalize: diacritics + tatweel removed", ArabicText.normalize("بَغْدَاد") == "بغداد" && ArabicText.normalize("الموصـل") == "الموصل")
    check("normalize: ة/ه and ى/ي unified", ArabicText.normalize("البصرة") == ArabicText.normalize("البصره") && ArabicText.normalize("كربلى") == ArabicText.normalize("كربلي"))
    check("normalize: Eastern digits -> Western", ArabicText.normalize("شارع ٦٠") == "شارع 60")
    check("isArabic", ArabicText.isArabic("بغداد") && !ArabicText.isArabic("Baghdad"))

    val focus = LatLng(33.3152, 44.3661)
    val cands = listOf(
        Place("a", "مطعم الرشيد", "بغداد", 33.31, 44.40, "restaurant"),
        Place("b", "الرشيد", "بغداد", 33.3, 44.37, "street"),
        Place("c", "الرشيد", "بغداد", 33.3002, 44.3702, "street"),       // near-duplicate of b
        Place("d", "الرشيد", "مدينة بعيدة", 36.19, 44.01, "street"),     // exact match but far
    )
    val ranked = Ranking.rank(cands, "الرشيد", focus)
    check("ranking: de-duplicates near-identical results", ranked.size == 3, "size=${ranked.size}")
    check("ranking: nearby exact match first", ranked.first().id == "b" || ranked.first().id == "c", "first=${ranked.first().id}")
    check("ranking: partial match after exact", ranked.last().id == "a" || ranked.indexOfFirst { it.id == "a" } == 2, ranked.map { it.id }.toString())

    // ---- Photon / Overpass parsers (HAND-WRITTEN fixtures shaped like their documented responses) ----
    val photon = """{"type":"FeatureCollection","features":[
      {"geometry":{"type":"Point","coordinates":[44.3661,33.3152]},"type":"Feature","properties":{"osm_id":123,"osm_type":"R","name":"بغداد","state":"بغداد","country":"العراق","osm_value":"city"}},
      {"geometry":{"type":"Point","coordinates":[47.78,30.51]},"type":"Feature","properties":{"osm_id":9,"osm_type":"N","name":"Basra","country":"Iraq"}},
      {"geometry":{"type":"Point","coordinates":[1.0,2.0]},"type":"Feature","properties":{}}]}"""
    val pp = PhotonParser.parse(photon)
    check("photon: parses 2 valid features, skips nameless", pp.size == 2, "size=${pp.size}")
    check("photon: lat/lon order (lon first in GeoJSON)", Math.abs(pp[0].lat - 33.3152) < 1e-9 && Math.abs(pp[0].lon - 44.3661) < 1e-9)
    check("photon: subtitle built without repeating name", pp[0].subtitle == "العراق" || pp[0].subtitle == "بغداد، العراق", "subtitle='${pp[0].subtitle}'")
    val ov = """{"elements":[
      {"type":"node","id":1,"lat":33.31,"lon":44.36,"tags":{"amenity":"fuel","name":"محطة الكرادة","name:en":"Karrada Station"}},
      {"type":"way","id":2,"center":{"lat":33.32,"lon":44.37},"tags":{"amenity":"fuel","name:en":"Only English"}},
      {"type":"node","id":3,"lat":33.33,"lon":44.38,"tags":{"amenity":"fuel"}}]}"""
    val oa = OverpassParser.parse(ov, "fuel", true)
    check("overpass: skips unnamed, handles way centers", oa.size == 2, "size=${oa.size}")
    check("overpass: prefers Arabic name when asked", oa[0].name == "محطة الكرادة")
    check("overpass: English preference", OverpassParser.parse(ov, "fuel", false)[0].name == "Karrada Station")

    val rt = Place.listFromJson(Place.listToJson(cands))
    check("Place JSON round-trip", rt == cands)
    check("Place JSON: garbage -> empty list", Place.listFromJson("{{not json").isEmpty())

    // ---- Map style template (the real generated assets) ----
    for (asset in args.drop(1)) {
        val tpl = java.io.File(asset).readText()
        for (lang in Lang.values()) {
            val filled = StyleTemplate.fill(tpl, "https://tiles.example/planet", "https://tiles.example/fonts/{fontstack}/{range}.pbf", lang)
            val root = kotlinx.serialization.json.Json.parseToJsonElement(filled) as kotlinx.serialization.json.JsonObject
            val layers = root["layers"] as kotlinx.serialization.json.JsonArray
            check("style ${java.io.File(asset).name}/$lang: valid JSON, no placeholders left", !filled.contains("__"), "left-over placeholder")
            check("style ${java.io.File(asset).name}/$lang: ${layers.size} layers incl. 3D buildings + labels",
                layers.any { it.toString().contains("building_3d") } && layers.any { it.toString().contains("road_label") })
            check("style ${java.io.File(asset).name}/$lang: label expression language-specific",
                if (lang == Lang.AR) filled.contains("\"name:ar\"") else filled.contains("\"name_en\""))
        }
    }

    // ---- Reports parser against the REAL server's output (file produced by tools/make_reports_fixture.py) ----
    if (args.isNotEmpty()) {
        val body = java.io.File(args[0]).readText()
        val list = ReportsParser.parseList(body)
        check("server JSON: parsed ${list.size} reports", list.size >= 2, "size=${list.size}")
        check("server JSON: 3 distinct types mapped to enum", list.map { it.type }.toSet() ==
            setOf(ReportType.POTHOLE, ReportType.CHECKPOINT, ReportType.TRAFFIC), "types=${list.map { it.type }}")
        val cp = list.firstOrNull { it.type == ReportType.CHECKPOINT }
        check("server JSON: checkpoint flagged unverified", cp != null && cp.unverifiedSensitive && !cp.verified)
        val pot = list.firstOrNull { it.type == ReportType.POTHOLE }
        check("server JSON: Arabic note survives", pot?.note == "حفرة كبيرة قرب الجسر", "note=${pot?.note}")
        check("server JSON: error body parsed", ReportsParser.errorMessage("""{"error":"rate_limited","message":"x"}""") == "rate_limited")
    }
}

fun pointAt(g: List<LatLng>, dist: Double): LatLng {
    var acc = 0.0
    for (i in 1 until g.size) {
        val seg = Geo.distance(g[i - 1], g[i])
        if (acc + seg >= dist) {
            val t = if (seg == 0.0) 0.0 else (dist - acc) / seg
            return LatLng(g[i - 1].lat + (g[i].lat - g[i - 1].lat) * t, g[i - 1].lon + (g[i].lon - g[i - 1].lon) * t)
        }
        acc += seg
    }
    return g.last()
}
