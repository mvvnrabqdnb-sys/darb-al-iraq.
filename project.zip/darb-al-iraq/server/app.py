#!/usr/bin/env python3
"""Darb Al-Iraq community reports server.

Pure Python standard library (http.server + sqlite3): no external dependencies.

Endpoints (all JSON):
  GET  /health
  POST /v1/devices                      -> {device_id, token}
  GET  /v1/reports?bbox=minLon,minLat,maxLon,maxLat   (or lat=&lon=&radius_km=)
  POST /v1/reports                      (Bearer device_id.token)
  POST /v1/reports/{id}/vote            (Bearer)  body: {"vote": "confirm"|"gone"}

Design notes:
  * Devices are anonymous. The server stores only a SHA-256 hash of the token.
  * No device location history is stored; only the report coordinates.
  * Reports expire by type-specific TTL; confirmations extend life,
    "gone" votes resolve the report early.
  * Sensitive categories (checkpoint) are never flagged verified until
    independently confirmed by other devices.
"""
import hashlib
import json
import math
import os
import re
import secrets
import sqlite3
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

# type -> base TTL in seconds
REPORT_TYPES = {
    "traffic": 60 * 60,
    "accident": 90 * 60,
    "pothole": 7 * 24 * 3600,
    "speedbump": 30 * 24 * 3600,
    "closure": 6 * 3600,
    "construction": 24 * 3600,
    "checkpoint": 4 * 3600,
    "hazard": 3 * 3600,
    "dust": 3 * 3600,
    "flood": 6 * 3600,
    "obstacle": 2 * 3600,
    "fuel": 12 * 3600,
}
# categories that must not be shown as confirmed until others confirm them
SENSITIVE_TYPES = {"checkpoint"}

MAX_BODY = 4096
MAX_NOTE = 140
DEDUP_RADIUS_M = 100.0
VERIFY_THRESHOLD = 2          # confirmations from other devices
RESOLVE_NET_DOWN = 2          # (gone - confirm) >= this resolves the report
REPORTS_PER_WINDOW = 10
VOTES_PER_WINDOW = 60
RATE_WINDOW = 600             # seconds
REGISTER_PER_IP_HOUR = 20
MAX_RESULTS = 300

SCHEMA = """
CREATE TABLE IF NOT EXISTS devices(
  id TEXT PRIMARY KEY,
  token_hash TEXT NOT NULL,
  created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS reports(
  id TEXT PRIMARY KEY,
  type TEXT NOT NULL,
  lat REAL NOT NULL,
  lon REAL NOT NULL,
  note TEXT,
  device_id TEXT NOT NULL,
  created_at REAL NOT NULL,
  expires_at REAL NOT NULL,
  status TEXT NOT NULL DEFAULT 'active'
);
CREATE INDEX IF NOT EXISTS idx_reports_geo ON reports(status, lat, lon);
CREATE TABLE IF NOT EXISTS votes(
  report_id TEXT NOT NULL,
  device_id TEXT NOT NULL,
  vote TEXT NOT NULL,
  created_at REAL NOT NULL,
  PRIMARY KEY(report_id, device_id)
);
CREATE TABLE IF NOT EXISTS actions(
  device_id TEXT NOT NULL,
  kind TEXT NOT NULL,
  at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_actions ON actions(device_id, kind, at);
"""


class ApiError(Exception):
    def __init__(self, status, code, message):
        super().__init__(message)
        self.status, self.code, self.message = status, code, message


def haversine_m(lat1, lon1, lat2, lon2):
    r = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


class Store:
    def __init__(self, path=":memory:", clock=time.time):
        self.clock = clock
        self.lock = threading.RLock()
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.executescript(SCHEMA)
        self.ip_register = {}  # ip -> [timestamps]

    # ---------- devices ----------
    def register_device(self, ip):
        now = self.clock()
        with self.lock:
            hits = [t for t in self.ip_register.get(ip, []) if now - t < 3600]
            if len(hits) >= REGISTER_PER_IP_HOUR:
                raise ApiError(429, "rate_limited", "too many registrations from this address")
            hits.append(now)
            self.ip_register[ip] = hits
            device_id = uuid.uuid4().hex
            token = secrets.token_urlsafe(32)
            self.db.execute(
                "INSERT INTO devices(id, token_hash, created_at) VALUES(?,?,?)",
                (device_id, hashlib.sha256(token.encode()).hexdigest(), now),
            )
            self.db.commit()
            return {"device_id": device_id, "token": f"{device_id}.{token}"}

    def authenticate(self, header):
        if not header or not header.startswith("Bearer "):
            raise ApiError(401, "unauthorized", "missing bearer token")
        raw = header[7:].strip()
        if "." not in raw:
            raise ApiError(401, "unauthorized", "malformed token")
        device_id, token = raw.split(".", 1)
        row = self.db.execute("SELECT token_hash FROM devices WHERE id=?", (device_id,)).fetchone()
        given = hashlib.sha256(token.encode()).hexdigest()
        if not row or not secrets.compare_digest(row["token_hash"], given):
            raise ApiError(401, "unauthorized", "invalid token")
        return device_id

    def _rate_check(self, device_id, kind, limit):
        now = self.clock()
        n = self.db.execute(
            "SELECT COUNT(*) c FROM actions WHERE device_id=? AND kind=? AND at>?",
            (device_id, kind, now - RATE_WINDOW),
        ).fetchone()["c"]
        if n >= limit:
            raise ApiError(429, "rate_limited", "too many actions, slow down")
        self.db.execute("INSERT INTO actions(device_id, kind, at) VALUES(?,?,?)", (device_id, kind, now))

    # ---------- reports ----------
    def _counts(self, report_id):
        rows = self.db.execute(
            "SELECT vote, COUNT(*) c FROM votes WHERE report_id=? GROUP BY vote", (report_id,)
        ).fetchall()
        d = {r["vote"]: r["c"] for r in rows}
        return d.get("confirm", 0), d.get("gone", 0)

    def _view(self, row):
        up, down = self._counts(row["id"])
        now = self.clock()
        ttl = REPORT_TYPES[row["type"]]
        age = max(0.0, now - row["created_at"])
        freshness = max(0.2, 1.0 - age / ttl)
        confidence = round(((up + 1) / (up + down + 2)) * freshness, 3)
        verified = up >= VERIFY_THRESHOLD
        return {
            "id": row["id"],
            "type": row["type"],
            "lat": row["lat"],
            "lon": row["lon"],
            "note": row["note"],
            "created_at": int(row["created_at"]),
            "expires_at": int(row["expires_at"]),
            "confirmations": up,
            "gone_votes": down,
            "verified": verified,
            "unverified_sensitive": row["type"] in SENSITIVE_TYPES and not verified,
            "confidence": confidence,
            "status": row["status"],
        }

    def _expire(self):
        self.db.execute(
            "UPDATE reports SET status='expired' WHERE status='active' AND expires_at<=?",
            (self.clock(),),
        )

    def create_report(self, device_id, body):
        rtype = body.get("type")
        if rtype not in REPORT_TYPES:
            raise ApiError(400, "invalid_type", "unknown report type")
        try:
            lat, lon = float(body.get("lat")), float(body.get("lon"))
        except (TypeError, ValueError):
            raise ApiError(400, "invalid_location", "lat/lon must be numbers")
        if not (math.isfinite(lat) and math.isfinite(lon)) or not (-90 <= lat <= 90) or not (-180 <= lon <= 180):
            raise ApiError(400, "invalid_location", "lat/lon out of range")
        note = body.get("note")
        if note is not None:
            if not isinstance(note, str) or len(note) > MAX_NOTE:
                raise ApiError(400, "invalid_note", f"note must be text up to {MAX_NOTE} characters")
            note = re.sub(r"[\x00-\x1f]", " ", note).strip() or None
        with self.lock:
            self._expire()
            self._rate_check(device_id, "report", REPORTS_PER_WINDOW)
            # de-duplicate: same type, still active, within radius
            d = DEDUP_RADIUS_M / 111000.0
            near = self.db.execute(
                "SELECT * FROM reports WHERE status='active' AND type=? AND lat BETWEEN ? AND ? AND lon BETWEEN ? AND ?",
                (rtype, lat - d, lat + d, lon - d * 2, lon + d * 2),
            ).fetchall()
            for row in near:
                if haversine_m(lat, lon, row["lat"], row["lon"]) <= DEDUP_RADIUS_M:
                    if row["device_id"] != device_id:
                        self._apply_vote(row, device_id, "confirm")
                    self.db.commit()
                    fresh = self.db.execute("SELECT * FROM reports WHERE id=?", (row["id"],)).fetchone()
                    view = self._view(fresh)
                    view["deduplicated"] = True
                    return view
            now = self.clock()
            rid = uuid.uuid4().hex
            self.db.execute(
                "INSERT INTO reports(id,type,lat,lon,note,device_id,created_at,expires_at) VALUES(?,?,?,?,?,?,?,?)",
                (rid, rtype, lat, lon, note, device_id, now, now + REPORT_TYPES[rtype]),
            )
            self.db.commit()
            view = self._view(self.db.execute("SELECT * FROM reports WHERE id=?", (rid,)).fetchone())
            view["deduplicated"] = False
            return view

    def _apply_vote(self, row, device_id, vote):
        existing = self.db.execute(
            "SELECT vote FROM votes WHERE report_id=? AND device_id=?", (row["id"], device_id)
        ).fetchone()
        now = self.clock()
        if existing:
            self.db.execute(
                "UPDATE votes SET vote=?, created_at=? WHERE report_id=? AND device_id=?",
                (vote, now, row["id"], device_id),
            )
        else:
            self.db.execute(
                "INSERT INTO votes(report_id,device_id,vote,created_at) VALUES(?,?,?,?)",
                (row["id"], device_id, vote, now),
            )
        up, down = self._counts(row["id"])
        if down - up >= RESOLVE_NET_DOWN:
            self.db.execute("UPDATE reports SET status='resolved' WHERE id=?", (row["id"],))
        elif vote == "confirm":
            ttl = REPORT_TYPES[row["type"]]
            new_exp = max(row["expires_at"], now + ttl / 2)
            self.db.execute("UPDATE reports SET expires_at=? WHERE id=?", (new_exp, row["id"]))

    def vote(self, device_id, report_id, vote):
        if vote not in ("confirm", "gone"):
            raise ApiError(400, "invalid_vote", "vote must be 'confirm' or 'gone'")
        with self.lock:
            self._expire()
            row = self.db.execute("SELECT * FROM reports WHERE id=?", (report_id,)).fetchone()
            if not row:
                raise ApiError(404, "not_found", "report not found")
            if row["status"] != "active":
                raise ApiError(409, "not_active", "report is no longer active")
            if row["device_id"] == device_id:
                raise ApiError(403, "own_report", "you cannot vote on your own report")
            self._rate_check(device_id, "vote", VOTES_PER_WINDOW)
            self._apply_vote(row, device_id, vote)
            self.db.commit()
            fresh = self.db.execute("SELECT * FROM reports WHERE id=?", (report_id,)).fetchone()
            return self._view(fresh)

    def list_reports(self, bbox):
        min_lon, min_lat, max_lon, max_lat = bbox
        with self.lock:
            self._expire()
            self.db.commit()
            rows = self.db.execute(
                "SELECT * FROM reports WHERE status='active' AND lat BETWEEN ? AND ? AND lon BETWEEN ? AND ? "
                "ORDER BY created_at DESC LIMIT ?",
                (min_lat, max_lat, min_lon, max_lon, MAX_RESULTS),
            ).fetchall()
            return [self._view(r) for r in rows]


def parse_bbox(qs):
    try:
        if "bbox" in qs:
            parts = [float(x) for x in qs["bbox"][0].split(",")]
            if len(parts) != 4:
                raise ValueError
            min_lon, min_lat, max_lon, max_lat = parts
        else:
            lat, lon = float(qs["lat"][0]), float(qs["lon"][0])
            km = min(float(qs.get("radius_km", ["10"])[0]), 100.0)
            dlat = km / 111.0
            dlon = km / (111.0 * max(0.01, math.cos(math.radians(lat))))
            min_lon, min_lat, max_lon, max_lat = lon - dlon, lat - dlat, lon + dlon, lat + dlat
    except (KeyError, ValueError):
        raise ApiError(400, "invalid_query", "provide bbox=minLon,minLat,maxLon,maxLat or lat,lon[,radius_km]")
    if not all(map(math.isfinite, (min_lon, min_lat, max_lon, max_lat))) or min_lat > max_lat or min_lon > max_lon:
        raise ApiError(400, "invalid_query", "invalid bounding box")
    if (max_lat - min_lat) > 5 or (max_lon - min_lon) > 5:
        raise ApiError(400, "area_too_large", "requested area too large (max 5 degrees)")
    return min_lon, min_lat, max_lon, max_lat


def make_handler(store):
    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, fmt, *args):  # no IP / path logging by default (privacy)
            if os.environ.get("DARB_LOG"):
                super().log_message(fmt, *args)

        def _send(self, status, payload):
            data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _body(self):
            try:
                length = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                raise ApiError(400, "invalid_body", "bad content length")
            if length > MAX_BODY:
                raise ApiError(413, "too_large", "request body too large")
            raw = self.rfile.read(length) if length else b""
            if not raw:
                return {}
            try:
                data = json.loads(raw.decode("utf-8"))
            except (ValueError, UnicodeDecodeError):
                raise ApiError(400, "invalid_json", "body must be valid JSON")
            if not isinstance(data, dict):
                raise ApiError(400, "invalid_json", "body must be a JSON object")
            return data

        def _route(self, method):
            url = urlparse(self.path)
            path = url.path.rstrip("/") or "/"
            if method == "GET" and path == "/health":
                return 200, {"status": "ok", "time": int(store.clock())}
            if method == "POST" and path == "/v1/devices":
                self._body()
                return 201, store.register_device(self.client_address[0])
            if method == "GET" and path == "/v1/reports":
                bbox = parse_bbox(parse_qs(url.query))
                return 200, {"reports": store.list_reports(bbox)}
            if method == "POST" and path == "/v1/reports":
                device = store.authenticate(self.headers.get("Authorization"))
                return 201, store.create_report(device, self._body())
            m = re.fullmatch(r"/v1/reports/([0-9a-f]{32})/vote", path)
            if method == "POST" and m:
                device = store.authenticate(self.headers.get("Authorization"))
                return 200, store.vote(device, m.group(1), self._body().get("vote"))
            raise ApiError(404, "not_found", "no such endpoint")

        def _handle(self, method):
            try:
                status, payload = self._route(method)
            except ApiError as e:
                status, payload = e.status, {"error": e.code, "message": e.message}
            except Exception:  # never leak internals
                status, payload = 500, {"error": "server_error", "message": "internal error"}
            self._send(status, payload)

        def do_GET(self):
            self._handle("GET")

        def do_POST(self):
            self._handle("POST")

    return Handler


def serve(host="0.0.0.0", port=8080, db_path="darb.sqlite3", store=None):
    store = store or Store(db_path)
    httpd = ThreadingHTTPServer((host, port), make_handler(store))
    return httpd, store


if __name__ == "__main__":
    httpd, _ = serve(
        host=os.environ.get("DARB_HOST", "0.0.0.0"),
        port=int(os.environ.get("DARB_PORT", "8080")),
        db_path=os.environ.get("DARB_DB", "darb.sqlite3"),
    )
    print(f"Darb Al-Iraq server listening on {httpd.server_address}")
    httpd.serve_forever()
