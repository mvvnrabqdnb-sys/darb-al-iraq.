import json
import os
import sys
import threading
import unittest
import urllib.error
import urllib.request

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import app  # noqa: E402

# Baghdad, Basra, Erbil
BAGHDAD = (33.3152, 44.3661)
BASRA = (30.5085, 47.7835)


class Clock:
    def __init__(self):
        self.t = 1_800_000_000.0

    def __call__(self):
        return self.t


class ApiTest(unittest.TestCase):
    def setUp(self):
        self.clock = Clock()
        self.store = app.Store(":memory:", clock=self.clock)
        self.httpd, _ = app.serve("127.0.0.1", 0, store=self.store)
        self.port = self.httpd.server_address[1]
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.httpd.shutdown()
        self.httpd.server_close()

    # --- helpers (real HTTP over localhost) ---
    def call(self, method, path, body=None, token=None):
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}{path}",
            data=json.dumps(body).encode() if body is not None else (b"{}" if method == "POST" else None),
            method=method,
            headers={"Content-Type": "application/json"},
        )
        if token:
            req.add_header("Authorization", f"Bearer {token}")
        try:
            with urllib.request.urlopen(req, timeout=5) as r:
                return r.status, json.loads(r.read())
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read())

    def device(self):
        status, data = self.call("POST", "/v1/devices")
        self.assertEqual(status, 201)
        return data["token"]

    def bbox(self, lat, lon, d=0.2):
        return f"/v1/reports?bbox={lon-d},{lat-d},{lon+d},{lat+d}"

    # --- tests ---
    def test_health(self):
        s, d = self.call("GET", "/health")
        self.assertEqual((s, d["status"]), (200, "ok"))

    def test_report_shared_between_two_devices(self):
        a, b = self.device(), self.device()
        s, rep = self.call("POST", "/v1/reports", {"type": "pothole", "lat": BAGHDAD[0], "lon": BAGHDAD[1], "note": "حفرة كبيرة"}, a)
        self.assertEqual(s, 201)
        # device B (never created it) sees it
        s, data = self.call("GET", self.bbox(*BAGHDAD))
        self.assertEqual(s, 200)
        self.assertEqual([r["id"] for r in data["reports"]], [rep["id"]])
        self.assertEqual(data["reports"][0]["note"], "حفرة كبيرة")
        # far-away query does not see it
        s, data = self.call("GET", self.bbox(*BASRA))
        self.assertEqual(data["reports"], [])

    def test_auth_required_and_invalid_token(self):
        s, d = self.call("POST", "/v1/reports", {"type": "traffic", "lat": 33, "lon": 44})
        self.assertEqual((s, d["error"]), (401, "unauthorized"))
        s, d = self.call("POST", "/v1/reports", {"type": "traffic", "lat": 33, "lon": 44}, "abc.def")
        self.assertEqual(s, 401)

    def test_validation(self):
        a = self.device()
        bad = [
            {"type": "nope", "lat": 33, "lon": 44},
            {"type": "traffic", "lat": 100, "lon": 44},
            {"type": "traffic", "lat": "x", "lon": 44},
            {"type": "traffic", "lat": 33, "lon": 44, "note": "x" * 500},
            {"type": "traffic", "lat": 33},
        ]
        for body in bad:
            s, d = self.call("POST", "/v1/reports", body, a)
            self.assertEqual(s, 400, body)

    def test_dedup_counts_as_confirmation(self):
        a, b = self.device(), self.device()
        s, r1 = self.call("POST", "/v1/reports", {"type": "accident", "lat": BAGHDAD[0], "lon": BAGHDAD[1]}, a)
        s, r2 = self.call("POST", "/v1/reports", {"type": "accident", "lat": BAGHDAD[0] + 0.0003, "lon": BAGHDAD[1]}, b)
        self.assertEqual(r2["id"], r1["id"])
        self.assertTrue(r2["deduplicated"])
        self.assertEqual(r2["confirmations"], 1)
        # same device re-reporting does not inflate
        s, r3 = self.call("POST", "/v1/reports", {"type": "accident", "lat": BAGHDAD[0], "lon": BAGHDAD[1]}, a)
        self.assertEqual(r3["confirmations"], 1)
        # different type at same place is a separate report
        s, r4 = self.call("POST", "/v1/reports", {"type": "hazard", "lat": BAGHDAD[0], "lon": BAGHDAD[1]}, a)
        self.assertNotEqual(r4["id"], r1["id"])

    def test_confirm_flow_and_verification(self):
        a, b, c = self.device(), self.device(), self.device()
        s, r = self.call("POST", "/v1/reports", {"type": "checkpoint", "lat": BAGHDAD[0], "lon": BAGHDAD[1]}, a)
        self.assertTrue(r["unverified_sensitive"])
        self.assertFalse(r["verified"])
        s, v = self.call("POST", f"/v1/reports/{r['id']}/vote", {"vote": "confirm"}, b)
        self.assertEqual(s, 200)
        self.assertTrue(v["unverified_sensitive"])  # one confirmation is not enough
        s, v = self.call("POST", f"/v1/reports/{r['id']}/vote", {"vote": "confirm"}, c)
        self.assertTrue(v["verified"])
        self.assertFalse(v["unverified_sensitive"])
        self.assertEqual(v["confirmations"], 2)

    def test_cannot_vote_on_own_report_and_vote_is_idempotent_per_device(self):
        a, b = self.device(), self.device()
        s, r = self.call("POST", "/v1/reports", {"type": "pothole", "lat": 33.0, "lon": 44.0}, a)
        s, d = self.call("POST", f"/v1/reports/{r['id']}/vote", {"vote": "confirm"}, a)
        self.assertEqual((s, d["error"]), (403, "own_report"))
        self.call("POST", f"/v1/reports/{r['id']}/vote", {"vote": "confirm"}, b)
        s, v = self.call("POST", f"/v1/reports/{r['id']}/vote", {"vote": "confirm"}, b)
        self.assertEqual(v["confirmations"], 1)  # same device cannot stack votes

    def test_gone_votes_resolve_report(self):
        a, b, c = self.device(), self.device(), self.device()
        s, r = self.call("POST", "/v1/reports", {"type": "closure", "lat": 33.1, "lon": 44.1}, a)
        self.call("POST", f"/v1/reports/{r['id']}/vote", {"vote": "gone"}, b)
        s, v = self.call("POST", f"/v1/reports/{r['id']}/vote", {"vote": "gone"}, c)
        self.assertEqual(v["status"], "resolved")
        s, data = self.call("GET", self.bbox(33.1, 44.1))
        self.assertEqual(data["reports"], [])
        s, d = self.call("POST", f"/v1/reports/{r['id']}/vote", {"vote": "confirm"}, b)
        self.assertEqual(s, 409)

    def test_expiry_by_type_and_confirmation_extends_life(self):
        a, b = self.device(), self.device()
        s, traffic = self.call("POST", "/v1/reports", {"type": "traffic", "lat": 33.2, "lon": 44.2}, a)
        s, pothole = self.call("POST", "/v1/reports", {"type": "pothole", "lat": 33.25, "lon": 44.25}, a)
        self.clock.t += 50 * 60
        self.call("POST", f"/v1/reports/{traffic['id']}/vote", {"vote": "confirm"}, b)  # extends
        self.clock.t += 20 * 60  # 70 min total: traffic base TTL (60) passed, but it was confirmed at 50
        ids = [r["id"] for r in self.call("GET", self.bbox(33.2, 44.2, 0.5))[1]["reports"]]
        self.assertIn(traffic["id"], ids)
        self.assertIn(pothole["id"], ids)
        self.clock.t += 2 * 3600  # traffic expired, pothole (7 days) still there
        ids = [r["id"] for r in self.call("GET", self.bbox(33.2, 44.2, 0.5))[1]["reports"]]
        self.assertNotIn(traffic["id"], ids)
        self.assertIn(pothole["id"], ids)
        self.clock.t += 8 * 24 * 3600
        self.assertEqual(self.call("GET", self.bbox(33.2, 44.2, 0.5))[1]["reports"], [])

    def test_rate_limit_reports(self):
        a = self.device()
        statuses = []
        for i in range(app.REPORTS_PER_WINDOW + 2):
            s, _ = self.call("POST", "/v1/reports", {"type": "hazard", "lat": 33 + i * 0.01, "lon": 44}, a)
            statuses.append(s)
        self.assertEqual(statuses[: app.REPORTS_PER_WINDOW], [201] * app.REPORTS_PER_WINDOW)
        self.assertEqual(statuses[-1], 429)
        self.clock.t += app.RATE_WINDOW + 1
        s, _ = self.call("POST", "/v1/reports", {"type": "hazard", "lat": 35, "lon": 44}, a)
        self.assertEqual(s, 201)

    def test_query_validation_and_radius_mode(self):
        a = self.device()
        self.call("POST", "/v1/reports", {"type": "fuel", "lat": BAGHDAD[0], "lon": BAGHDAD[1]}, a)
        s, d = self.call("GET", f"/v1/reports?lat={BAGHDAD[0]}&lon={BAGHDAD[1]}&radius_km=5")
        self.assertEqual((s, len(d["reports"])), (200, 1))
        self.assertEqual(self.call("GET", "/v1/reports")[0], 400)
        self.assertEqual(self.call("GET", "/v1/reports?bbox=0,0,50,50")[1]["error"], "area_too_large")

    def test_body_too_large_and_bad_json(self):
        a = self.device()
        s, d = self.call("POST", "/v1/reports", {"type": "traffic", "lat": 33, "lon": 44, "pad": "x" * 6000}, a)
        self.assertEqual(s, 413)

    def test_unknown_route(self):
        self.assertEqual(self.call("GET", "/nope")[0], 404)


if __name__ == "__main__":
    unittest.main(verbosity=2)
