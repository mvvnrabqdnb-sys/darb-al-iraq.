#!/usr/bin/env python3
"""Generates the Darb Al-Iraq MapLibre styles (day + night) in the OpenMapTiles schema.

Output: android/app/src/main/assets/style_day.json, style_night.json

Placeholders left inside the JSON for the app to substitute at runtime:
  __TILEJSON_URL__   TileJSON of the vector tile source (OpenMapTiles schema)
  __GLYPHS_URL__     glyph PBF template, e.g. https://host/fonts/{fontstack}/{range}.pbf
  __NAME_EXPR__      replaced by a JSON expression choosing the Arabic or English label
"""
import json
import os
import sys

FONT_REG = ["Noto Sans Regular"]
FONT_BOLD = ["Noto Sans Bold"]

PALETTES = {
    "day": dict(
        bg="#eef1f5", land="#e9ecef", park="#cfe8c9", wood="#bfe0b6", sand="#f1e9d2", res="#e4e8ee",
        water="#a9d3f0", building="#d5dae2", building3d="#c9cfd9", boundary="#9aa5b8",
        motorway="#ff9a3c", motorway_c="#c46a14", trunk="#ffb85c", trunk_c="#c98228",
        primary="#ffe082", primary_c="#c9a93c", secondary="#ffffff", secondary_c="#aab4c3",
        tertiary="#ffffff", tertiary_c="#b9c2cf", minor="#ffffff", minor_c="#c7cfda",
        service="#f7f9fb", service_c="#d2d9e2", path="#b8c0cc", rail="#9aa5b8",
        text="#26324a", halo="#ffffff", water_text="#3b7aa8", place="#1d2a44",
    ),
    "night": dict(
        bg="#101728", land="#141c2f", park="#16301f", wood="#143022", sand="#222436", res="#182238",
        water="#0b2745", building="#1f2a42", building3d="#26334f", boundary="#4b5a78",
        motorway="#e8812a", motorway_c="#6e3a0c", trunk="#d9983f", trunk_c="#6b4916",
        primary="#c9b25a", primary_c="#5a4e1c", secondary="#5d6f95", secondary_c="#222c45",
        tertiary="#4f6086", tertiary_c="#1f2840", minor="#42527a", minor_c="#1a2238",
        service="#33415f", service_c="#161d30", path="#33415f", rail="#4b5a78",
        text="#d6deef", halo="#101728", water_text="#6da6d6", place="#f1f5ff",
    ),
}

CLASS_STYLE = [
    # class, color key, casing key, min zoom, (z, width) stops for fill
    ("service", "service", "service_c", 14, [(14, 0.8), (18, 6)]),
    ("minor", "minor", "minor_c", 12, [(12, 0.6), (15, 3), (18, 12)]),
    ("tertiary", "tertiary", "tertiary_c", 10, [(10, 0.8), (14, 3), (18, 16)]),
    ("secondary", "secondary", "secondary_c", 8, [(8, 0.8), (12, 3), (18, 20)]),
    ("primary", "primary", "primary_c", 6, [(6, 0.8), (12, 4), (18, 24)]),
    ("trunk", "trunk", "trunk_c", 5, [(5, 0.8), (12, 5), (18, 26)]),
    ("motorway", "motorway", "motorway_c", 4, [(4, 0.8), (12, 6), (18, 28)]),
]


def interp(stops, factor=1.0):
    expr = ["interpolate", ["exponential", 1.4], ["zoom"]]
    for z, w in stops:
        expr += [z, round(w * factor, 2)]
    return expr


def build(mode):
    c = PALETTES[mode]
    layers = []

    def add(layer):
        layers.append(layer)

    add({"id": "background", "type": "background", "paint": {"background-color": c["bg"]}})
    add({"id": "landcover_grass", "type": "fill", "source": "omt", "source-layer": "landcover",
         "filter": ["in", "class", "grass", "farmland"], "paint": {"fill-color": c["park"], "fill-opacity": 0.55}})
    add({"id": "landcover_wood", "type": "fill", "source": "omt", "source-layer": "landcover",
         "filter": ["==", "class", "wood"], "paint": {"fill-color": c["wood"], "fill-opacity": 0.6}})
    add({"id": "landcover_sand", "type": "fill", "source": "omt", "source-layer": "landcover",
         "filter": ["==", "class", "sand"], "paint": {"fill-color": c["sand"], "fill-opacity": 0.7}})
    add({"id": "landuse_res", "type": "fill", "source": "omt", "source-layer": "landuse",
         "filter": ["in", "class", "residential", "suburb", "neighbourhood"], "minzoom": 6,
         "paint": {"fill-color": c["res"], "fill-opacity": 0.8}})
    add({"id": "park", "type": "fill", "source": "omt", "source-layer": "park",
         "paint": {"fill-color": c["park"], "fill-opacity": 0.8}})
    add({"id": "water", "type": "fill", "source": "omt", "source-layer": "water",
         "paint": {"fill-color": c["water"]}})
    add({"id": "waterway", "type": "line", "source": "omt", "source-layer": "waterway", "minzoom": 8,
         "paint": {"line-color": c["water"], "line-width": interp([(8, 0.5), (14, 2), (18, 6)])}})
    add({"id": "aeroway", "type": "fill", "source": "omt", "source-layer": "aeroway", "minzoom": 11,
         "filter": ["==", "$type", "Polygon"], "paint": {"fill-color": c["service"], "fill-opacity": 0.6}})
    add({"id": "building", "type": "fill", "source": "omt", "source-layer": "building", "minzoom": 13, "maxzoom": 15,
         "paint": {"fill-color": c["building"], "fill-opacity": 0.9}})
    add({"id": "building_3d", "type": "fill-extrusion", "source": "omt", "source-layer": "building", "minzoom": 15,
         "paint": {
             "fill-extrusion-color": c["building3d"],
             "fill-extrusion-height": ["coalesce", ["get", "render_height"], 6],
             "fill-extrusion-base": ["coalesce", ["get", "render_min_height"], 0],
             "fill-extrusion-opacity": 0.85,
         }})

    # roads: casings first (all classes), then fills so intersections look clean
    road_filter = lambda cls: ["all", ["==", "$type", "LineString"], ["==", "class", cls]]
    for cls, color, casing, minz, stops in CLASS_STYLE:
        add({"id": f"road_{cls}_casing", "type": "line", "source": "omt", "source-layer": "transportation",
             "minzoom": minz, "filter": road_filter(cls),
             "layout": {"line-cap": "round", "line-join": "round"},
             "paint": {"line-color": c[casing], "line-width": interp(stops, 1.0 + 0.0) if False else
                       ["interpolate", ["exponential", 1.4], ["zoom"]] + sum([[z, round(w + max(1.0, w * 0.25), 2)] for z, w in stops], [])}})
    for cls, color, casing, minz, stops in CLASS_STYLE:
        add({"id": f"road_{cls}", "type": "line", "source": "omt", "source-layer": "transportation",
             "minzoom": minz, "filter": road_filter(cls),
             "layout": {"line-cap": "round", "line-join": "round"},
             "paint": {"line-color": c[color], "line-width": interp(stops)}})
    add({"id": "road_path", "type": "line", "source": "omt", "source-layer": "transportation", "minzoom": 15,
         "filter": ["all", ["==", "$type", "LineString"], ["in", "class", "path", "track"]],
         "paint": {"line-color": c["path"], "line-width": 1, "line-dasharray": [2, 2]}})
    add({"id": "rail", "type": "line", "source": "omt", "source-layer": "transportation", "minzoom": 11,
         "filter": ["all", ["==", "$type", "LineString"], ["==", "class", "rail"]],
         "paint": {"line-color": c["rail"], "line-width": 1, "line-dasharray": [3, 3]}})
    add({"id": "boundary_admin", "type": "line", "source": "omt", "source-layer": "boundary",
         "filter": ["<=", "admin_level", 4],
         "paint": {"line-color": c["boundary"], "line-width": 1, "line-dasharray": [4, 2]}})

    # labels (names chosen by language expression)
    add({"id": "water_name", "type": "symbol", "source": "omt", "source-layer": "water_name", "minzoom": 5,
         "layout": {"text-field": "__NAME_EXPR__", "text-font": FONT_REG, "text-size": 12},
         "paint": {"text-color": c["water_text"], "text-halo-color": c["halo"], "text-halo-width": 1}})
    add({"id": "road_label", "type": "symbol", "source": "omt", "source-layer": "transportation_name", "minzoom": 13,
         "layout": {"text-field": "__NAME_EXPR__", "text-font": FONT_REG, "symbol-placement": "line",
                    "text-size": interp([(13, 10), (18, 14)]), "text-max-angle": 30},
         "paint": {"text-color": c["text"], "text-halo-color": c["halo"], "text-halo-width": 1.5}})
    add({"id": "poi", "type": "circle", "source": "omt", "source-layer": "poi", "minzoom": 15,
         "filter": ["<=", "rank", 20],
         "paint": {"circle-radius": 3.5, "circle-color": c["boundary"], "circle-stroke-color": c["halo"], "circle-stroke-width": 1}})
    add({"id": "poi_label", "type": "symbol", "source": "omt", "source-layer": "poi", "minzoom": 16,
         "filter": ["<=", "rank", 20],
         "layout": {"text-field": "__NAME_EXPR__", "text-font": FONT_REG, "text-size": 11, "text-anchor": "top", "text-offset": [0, 0.6]},
         "paint": {"text-color": c["text"], "text-halo-color": c["halo"], "text-halo-width": 1.2}})
    add({"id": "place_suburb", "type": "symbol", "source": "omt", "source-layer": "place", "minzoom": 12,
         "filter": ["in", "class", "suburb", "neighbourhood", "quarter"],
         "layout": {"text-field": "__NAME_EXPR__", "text-font": FONT_REG, "text-size": interp([(12, 11), (16, 15)])},
         "paint": {"text-color": c["text"], "text-halo-color": c["halo"], "text-halo-width": 1.5}})
    add({"id": "place_village", "type": "symbol", "source": "omt", "source-layer": "place", "minzoom": 9,
         "filter": ["in", "class", "village", "town"],
         "layout": {"text-field": "__NAME_EXPR__", "text-font": FONT_REG, "text-size": interp([(9, 11), (14, 15)])},
         "paint": {"text-color": c["place"], "text-halo-color": c["halo"], "text-halo-width": 1.5}})
    add({"id": "place_city", "type": "symbol", "source": "omt", "source-layer": "place", "minzoom": 4,
         "filter": ["==", "class", "city"],
         "layout": {"text-field": "__NAME_EXPR__", "text-font": FONT_BOLD, "text-size": interp([(4, 12), (10, 18), (14, 22)])},
         "paint": {"text-color": c["place"], "text-halo-color": c["halo"], "text-halo-width": 2}})
    add({"id": "place_country", "type": "symbol", "source": "omt", "source-layer": "place", "maxzoom": 6,
         "filter": ["in", "class", "country", "state"],
         "layout": {"text-field": "__NAME_EXPR__", "text-font": FONT_BOLD, "text-size": 13},
         "paint": {"text-color": c["place"], "text-halo-color": c["halo"], "text-halo-width": 2}})

    return {
        "version": 8,
        "name": f"darb-{mode}",
        "glyphs": "__GLYPHS_URL__",
        "sources": {"omt": {"type": "vector", "url": "__TILEJSON_URL__"}},
        "layers": layers,
    }


def validate(style):
    """Structural checks we can do without a renderer."""
    ids = [l["id"] for l in style["layers"]]
    assert len(ids) == len(set(ids)), "duplicate layer ids"
    for l in style["layers"]:
        if l["type"] != "background":
            assert l["source"] in style["sources"], f"bad source in {l['id']}"
            assert "source-layer" in l, f"missing source-layer in {l['id']}"
        if l["type"] == "symbol":
            assert l["layout"]["text-field"] == "__NAME_EXPR__"
            assert "text-font" in l["layout"], f"symbol {l['id']} needs text-font"
    json.dumps(style)


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(__file__), "..", "android", "app", "src", "main", "assets")
    os.makedirs(out, exist_ok=True)
    for mode in ("day", "night"):
        style = build(mode)
        validate(style)
        path = os.path.join(out, f"style_{mode}.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(style, f, ensure_ascii=False, indent=1)
        print(f"wrote {path}: {len(style['layers'])} layers")
