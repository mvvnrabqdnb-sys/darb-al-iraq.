#!/usr/bin/env python3
"""Starts the REAL reports server in-process, creates reports as two devices, and writes the
actual GET /v1/reports response body to the given file. Used to feed the Kotlin parser checks."""
import json
import os
import sys
import threading
import urllib.request

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "server"))
import app  # noqa: E402


def call(port, method, path, body=None, token=None):
    req = urllib.request.Request(
        f"http://127.0.0.1:{port}{path}",
        data=json.dumps(body).encode() if body is not None else (b"{}" if method == "POST" else None),
        method=method, headers={"Content-Type": "application/json"})
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    with urllib.request.urlopen(req, timeout=5) as r:
        return json.loads(r.read())


httpd, _ = app.serve("127.0.0.1", 0, db_path=":memory:")
port = httpd.server_address[1]
threading.Thread(target=httpd.serve_forever, daemon=True).start()
a = call(port, "POST", "/v1/devices")["token"]
b = call(port, "POST", "/v1/devices")["token"]
call(port, "POST", "/v1/reports", {"type": "pothole", "lat": 33.3152, "lon": 44.3661, "note": "حفرة كبيرة قرب الجسر"}, a)
call(port, "POST", "/v1/reports", {"type": "checkpoint", "lat": 33.32, "lon": 44.40}, b)
call(port, "POST", "/v1/reports", {"type": "traffic", "lat": 33.30, "lon": 44.35}, b)
raw = urllib.request.urlopen(f"http://127.0.0.1:{port}/v1/reports?bbox=44,33,45,34", timeout=5).read()
with open(sys.argv[1], "wb") as f:
    f.write(raw)
print(f"wrote real server response ({len(raw)} bytes) to {sys.argv[1]}")
httpd.shutdown()
