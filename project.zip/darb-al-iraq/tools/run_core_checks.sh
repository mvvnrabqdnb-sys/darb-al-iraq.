#!/usr/bin/env bash
# Compiles and runs the pure-Kotlin core checks using the Kotlin compiler bundled inside Gradle.
# Works offline. Usage: tools/run_core_checks.sh [GRADLE_HOME]
set -euo pipefail
GH="${1:-${GRADLE_HOME:-/opt/gradle}}"
L="$GH/lib"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$(mktemp -d)"
KCP="$L/kotlin-compiler-embeddable-2.0.21.jar:$L/kotlin-stdlib-2.0.21.jar:$L/kotlin-script-runtime-2.0.21.jar:$L/kotlin-reflect-2.0.21.jar:$L/kotlin-daemon-embeddable-2.0.21.jar:$L/trove4j-1.0.20200330.jar:$L/annotations-24.0.1.jar:$L/kotlinx-coroutines-core-jvm-1.6.4.jar"
LIBS="$L/kotlin-stdlib-2.0.21.jar:$L/kotlinx-serialization-core-jvm-1.6.2.jar:$L/kotlinx-serialization-json-jvm-1.6.2.jar"
java -cp "$KCP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect \
  -cp "$LIBS" -d "$OUT" \
  "$ROOT"/android/app/src/main/java/iq/darb/app/core/*.kt "$ROOT"/android/core-checks/CoreChecks.kt
python3 -I "$ROOT/tools/make_reports_fixture.py" "$OUT/reports.json"
python3 -I "$ROOT/tools/gen_styles.py" "$OUT/styles" >/dev/null
java -Dfile.encoding=UTF-8 -cp "$OUT:$LIBS" CoreChecksKt "$OUT/reports.json" "$OUT/styles/style_day.json" "$OUT/styles/style_night.json"
